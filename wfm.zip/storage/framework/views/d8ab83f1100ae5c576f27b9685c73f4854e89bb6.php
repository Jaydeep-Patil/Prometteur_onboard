<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Bootstrap Css -->
    <link rel="stylesheet" href="<?php echo e(asset('fronts/fontawsome/all.min.css')); ?>">
    <link href="<?php echo e(asset('fronts/css/bootstrap.min.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('fronts/css/bootstrap-select.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('fronts/css/dashboard6.css')); ?>" rel="stylesheet" />
    <style>
        .wrapper-panel {align-items:stretch;width:100%;height:auto;margin:0 auto;padding:0;position:relative;}
    </style>
</head>

<body>
   <?php echo $__env->yieldContent('content'); ?>
</body>
<script src="<?php echo e(asset('fronts/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('fronts/js/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('fronts/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('fronts/js/bootstrap-select.js')); ?>"></script>
<script src="<?php echo e(asset('fronts/js/jquery.scrollbar.js')); ?>"></script>
 <?php echo $__env->yieldContent('script'); ?>
</html>
<?php /**PATH D:\xampp\htdocs\wfm\resources\views/layouts/front.blade.php ENDPATH**/ ?>