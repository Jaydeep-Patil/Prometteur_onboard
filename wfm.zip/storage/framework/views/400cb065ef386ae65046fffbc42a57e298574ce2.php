<?php $__env->startSection('content'); ?>
<div class="wrapper-panel">
   <div class="login-comman login-right">
      <div class="bg-span"></div>
      <div class="accountwelocme_box">
         <h1>WFM Self-Assessment</h1>
         <p>This assessment guides you to the opportunities for improving <br>your Financials & CX.</p>
         <button type="button" class="letstartBtn">Let’s start <i
            class="fal fa-long-arrow-alt-right"></i></button>
      </div>
   </div>
   <!-- ======== Account Process Form ====== -->
   <div class="accountproce-container" id="accountSidebar">
      <button id="accountClose" class="accounthide" type="button"> <i class="far fa-times"></i></button>
      <div class="account_step_form">
         <form id="accountForms" class="accountForm" action="index.php" method="post">
            <!-- progressbar -->
            <ul id="progressbarAct" class="progressbar_ul">
               <li class="active">Account Details</li>
               <li>Contents</li>
               <li>General Overview</li>
               <li>Detailed Information</li>
               <li>Process Information</li>
               <li>Files Information</li>
               <li>Summary Details</li>
            </ul>
            <!-- ========= Register Tab ======= -->
           
            <fieldset class="fielset_panel fielset_height" data-route="<?php echo e(route('clients.store')); ?>" data-name="client_info">  
               <div class="scrollbarbar">
                  <div class="container">
                     <div class="row d-flex align-items-center justify-content-center">
                        <div class="col col-lg-10 col-12">
                           <div class="input_contianer">
                              <h3 class="mb-5">Let’s start by understanding your Business / Process and People.</h3>
                              <div class="row d-flex align-items-center justify-content-center">
                                 <div class="col col-lg-6 col-12">
                                    <input type="hidden" name="client_id" class="client_id" value="">
                                    <div class="form-group mb-4">
                                        <input type="text" class="form-control" placeholder="Name" name="name" id="client_name" required>
                                    </div>
                                    <div class="form-group">
                                      <input type="email" class="form-control" placeholder="Business Email" name="email" id="client_email" required>
                                    </div>
                                 </div>
                              </div>
                            
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="footerBtn-panel">
                     <button type="button" class="action-button previous_button">Back</button>
                     <button type="button" class="next action-button">Save & Continue</button>
                  </div>
               </div>
            </fieldset>

            <!-- ========= Content Tab ======= -->
            <fieldset class="fielset_panel fielset_height">
               <div class="scrollbarbar">
                  <div class="container">
                     <div class="row d-flex align-items-center justify-content-center">
                        <div class="col col-lg-6 col-12">
                           <div class="input_contianer">
                              <h3>Let’s start by understanding your Business / Process and People.</h3>
                              <ul class="content_ul mt-4">
                                 <li>
                                    <a href="#">
                                       <h4>General Overview - By Account</h4>
                                       <span>Not Started</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="#">
                                       <h4>Detailed Information - By Account</h4>
                                       <span>Not Started</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="#">
                                       <h4>Process Information - By Account</h4>
                                       <span>Not Started</span>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="#">
                                       <h4>Files Information</h4>
                                       <span>Not Started</span>
                                    </a>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="footerBtn-panel">
                     <button type="button" class="action-button previous previous_button">Back</button>
                     <button type="button" class="next action-button">Save & Continue</button>
                  </div>
               </div>
            </fieldset>
            <!-- ========= General Overview Tab ======= -->
            <fieldset class="fielset_panel fielset_height" data-route="<?php echo e(route('accounts.store')); ?>" data-name="general_info">
               <div class="scrollbarbar">
                  <div class="generalTableForm">
                     <div class="account_more"></div>
                     <div class="addmorePanel text-left mt-4">
                        <a href="javascript:void(0);" id="addmore_acount">Add Account</a>
                     </div>
                  </div>
                  <div class="footerBtn-panel">
                     <button type="button" class="action-button previous previous_button">Back</button>
                     <button type="button" class="next action-button">Save & Continue</button>
                  </div>
               </div>
            </fieldset>
            <!-- ========= Detailed Information Tab ======= -->
            <fieldset class="fielset_panel fielset_height">
               <div class="scrollbarbar">
                  <div style="width:100%;position:relative;">
                     <div class="details-container text-left mb-5">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                           <h2>Account - <span>Apple</span></h2>
                           <button class="cloneBtn" type="button" data-toggle="modal" data-target="#cloneDataModal"><i class="far fa-clone"></i>Clone Data</button>
                        </div>
                        <div class="accordion" id="accordionAccount1">
                           <div class="card">
                              <div class="card-header" id="headingOne">
                                 <h2 class="mb-0">
                                    <button class="btn btn-link btn-block text-left d-flex align-items-center justify-content-between" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                       LOB One
                                       <div class="completion_div">
                                          <small>Completion Percent</small>
                                          <div class="progress">
                                             <div class="progress-bar progress-bar-striped bg-danger" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">50%</div>
                                          </div>
                                       </div>
                                    </button>
                                 </h2>
                              </div>
                              <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionAccount1">
                                 <div class="card-body">
                                    <ul class="nav nav-tabs md-tabs boxparent-tabs mb-2" role="tablist">
                                       <li role="presentation" class="nav-item"><a class="active nav-link" href="#channelTab1" aria-controls="channelTab1" role="tab" data-toggle="tab">Chat</a></li>
                                       <li role="presentation" class="nav-item"><a class="nav-link" href="#channelTab2" aria-controls="channelTab2" role="tab" data-toggle="tab">Voice</a></li>
                                    </ul>
                                    <div class="tab-content">
                                       <!-- ================= channel One Tab  ================ -->
                                       <div role="tabpanel" class="tab-pane tabRamp-pane fade show active" id="channelTab1">
                                          <div class="text-left accoutList">
                                             <ul>
                                                <li><strong>Country -</strong> India</li>
                                                <li><strong>City Name -</strong> Pune</li>
                                                <li><strong>Site Name -</strong> Lorum Parum</li>
                                                <li><strong>Language -</strong> English</li>
                                             </ul>
                                          </div>
                                          <!-- ==== Billability ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Billability</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="How is the billing done for the account"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Method">
                                                            <option>Monthly FTE</option>
                                                            <option>Incenter Hours</option>
                                                            <option>Production Hour</option>
                                                            <option>Productive Hour with interval compliance caps</option>
                                                            <option>Handle Minutes</option>
                                                            <option>Per Call</option>
                                                            <option>Per Call Tiered Pricing</option>
                                                            <option>Per Minute with Occupancy Adjustment</option>
                                                            <option>Per Minute with AHT Cap</option>
                                                            <option>Per Minute when only Talk Time and ACW are paid</option>
                                                            <option>Per Minute when only Talk Time and Hold are paid</option>
                                                            <option>Per Minute when only Talk Time is Paid</option>
                                                            <option>Per E-mail Processed</option>
                                                            <option>Per Workstation</option>
                                                            <option>Per Sale</option>
                                                            <option>Per Chat</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the parameter basis which the billing is capped. <br>Eg. <br> AHT @ 300 secs <br> Occ% @ 82%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Cap" id="billingCapDrop">
                                                            <option value="occupancy">Occupancy</option>
                                                            <option value="aht">AHT</option>
                                                            <option value="notapplicable">Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0 billing_cap_input" id="biilingCapPer">
                                                      <div class="fg-control fg_control_span">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Enter Value for selected Billing Cap"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Enter Value">
                                                         <span>%</span>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0 billing_cap_input" id="biilingCapSec">
                                                      <div class="fg-control fg_control_span">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Enter Value for selected Billing Cap"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Enter Value">
                                                         <span>Sec</span>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the minimun guarantee for Billing. <br>Eg. <br> 85% of locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Guarantee">
                                                            <option>100%</option>
                                                            <option>95%</option>
                                                            <option>90%</option>
                                                            <option>85%</option>
                                                            <option>80%</option>
                                                            <option>75%</option>
                                                            <option>70%</option>
                                                            <option>65%</option>
                                                            <option>60%</option>
                                                            <option>55%</option>
                                                            <option>50%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the reference parameter for min. guarantee. <br>Eg. <br> 80% of the locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                            <option>Current Run Rate</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the maximum billing. <br>Eg. <br> 110% of locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billable Threshold">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the input parameter for max billing. <br>Eg. <br> 110% of the locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12 col-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== KPIs & Objective ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>KPIs & Objectives</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 1 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 1 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 2 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 2 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Center is liable to staff upto 110% of the Interval / Daily Lock"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="SOW Max Staffing Req?">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Operating Hours ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Operating Hours - <i class="fad fa-info-circle" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="General operating hours of the Programs / LOBs"></i></h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Weekday Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Weekday End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sat Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sat End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sun Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sun End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Employee Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Employee Details</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 40 hrs or as per SOW/Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Full-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 20-30 hrs or as per Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Part-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Seasonal hires, contractual hires"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Contractual Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== System Information ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>System Information</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of the ACD- Avaya, Cisco, Aws etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="ACD Name">
                                                            <option>INCONTACT</option>
                                                            <option>AWS CONNECT</option>
                                                            <option>CISCO</option>
                                                            <option>AVAYA</option>
                                                            <option>GENESYS</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of WFM Scheduling Tool Verint, Nice"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="WFM Tool">
                                                            <option>NICE</option>
                                                            <option>VERINT</option>
                                                            <option>ASPECT</option>
                                                            <option>GENESYS</option>
                                                            <option>CALABRIO</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of Backoffice support tool - Kana, Salesforce"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Back office Tool">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Training, Authorized Locations and Process Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <div class="row">
                                                <!-- ==== Training Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Training Details</h5>
                                                   <div class="form-group mb-4">
                                                      <input type="text" class="form-control" placeholder="Classroom Training Duration (Weeks)">
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <input type="text" class="form-control" placeholder="Nesting / OJT Duration (Weeks)">
                                                   </div>
                                                </div>
                                                <!-- ==== Authorized Locations Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Authorized Locations</h5>
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Work in Office">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Work from Home">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <!-- ==== Process Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Process Details</h5>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the program segment. <br>Eg. <br> Telecom, Retail etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Industry Segment (Eg : Finance, Retail, Insurance, Banking)">
                                                            <option>Retail</option>
                                                            <option>Telecom</option>
                                                            <option>Fintech</option>
                                                            <option>Bankng</option>
                                                            <option>e-Com</option>
                                                            <option>Insurance</option>
                                                            <option>Health Care</option>
                                                            <option>Customer Service</option>
                                                            <option>Others</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0" style="margin-top:33px;">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                                <!-- <div class="form-group col-lg-3 col-md-4">
                                                   <input type="text" class="form-control" placeholder="Total Training Duration (Weeks)">
                                                   </div> -->
                                             </div>
                                          </div>
                                          <div class="saveChannel text-center mt-4">
                                             <button type="button">Save Chaneel</button>
                                          </div>
                                       </div>
                                       <!-- ================= channel Two Tab  ================ -->
                                       <div role="tabpanel" class="tab-pane tabRamp-pane fade" id="channelTab2">
                                          <div class="text-left accoutList">
                                             <ul>
                                                <li><strong>Country -</strong> India</li>
                                                <li><strong>City Name -</strong> Pune</li>
                                                <li><strong>Site Name -</strong> Lorum Parum</li>
                                                <li><strong>Language -</strong> English</li>
                                             </ul>
                                          </div>
                                          <!-- ==== Billability ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Billability</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="How is the billing done for the account"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Method">
                                                            <option>Monthly FTE</option>
                                                            <option>Incenter Hours</option>
                                                            <option>Production Hour</option>
                                                            <option>Productive Hour with interval compliance caps</option>
                                                            <option>Handle Minutes</option>
                                                            <option>Per Call</option>
                                                            <option>Per Call Tiered Pricing</option>
                                                            <option>Per Minute with Occupancy Adjustment</option>
                                                            <option>Per Minute with AHT Cap</option>
                                                            <option>Per Minute when only Talk Time and ACW are paid</option>
                                                            <option>Per Minute when only Talk Time and Hold are paid</option>
                                                            <option>Per Minute when only Talk Time is Paid</option>
                                                            <option>Per E-mail Processed</option>
                                                            <option>Per Workstation</option>
                                                            <option>Per Sale</option>
                                                            <option>Per Chat</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the parameter basis which the billing is capped. <br>Eg. <br> AHT @ 300 secs <br> Occ% @ 82%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Cap">
                                                            <option>Occupancy</option>
                                                            <option>AHT</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Enter Value for selected Billing Cap"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Enter Value">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the minimun guarantee for Billing. <br>Eg. <br> 85% of locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Guarantee">
                                                            <option>100%</option>
                                                            <option>95%</option>
                                                            <option>90%</option>
                                                            <option>85%</option>
                                                            <option>80%</option>
                                                            <option>75%</option>
                                                            <option>70%</option>
                                                            <option>65%</option>
                                                            <option>60%</option>
                                                            <option>55%</option>
                                                            <option>50%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the reference parameter for min. guarantee. <br>Eg. <br> 80% of the locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                            <option>Current Run Rate</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the maximum billing. <br>Eg. <br> 110% of locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billable Threshold">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the input parameter for max billing. <br>Eg. <br> 110% of the locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12 col-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== KPIs & Objective ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>KPIs & Objectives</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 1 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 1 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 2 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 2 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Center is liable to staff upto 110% of the Interval / Daily Lock"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="SOW Max Staffing Req?">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Operating Hours ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Operating Hours - <i class="fad fa-info-circle" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="General operating hours of the Programs / LOBs"></i></h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Weekday Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Weekday End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sat Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sat End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sun Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sun End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Employee Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Employee Details</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 40 hrs or as per SOW/Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Full-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 20-30 hrs or as per Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Part-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Seasonal hires, contractual hires"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Contractual Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== System Information ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>System Information</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of the ACD- Avaya, Cisco, Aws etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="ACD Name">
                                                            <option>INCONTACT</option>
                                                            <option>AWS CONNECT</option>
                                                            <option>CISCO</option>
                                                            <option>AVAYA</option>
                                                            <option>GENESYS</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of WFM Scheduling Tool Verint, Nice"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="WFM Tool">
                                                            <option>NICE</option>
                                                            <option>VERINT</option>
                                                            <option>ASPECT</option>
                                                            <option>GENESYS</option>
                                                            <option>CALABRIO</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of Backoffice support tool - Kana, Salesforce"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Back office Tool">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Training, Authorized Locations and Process Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <div class="row">
                                                <!-- ==== Training Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Training Details</h5>
                                                   <div class="form-group mb-4">
                                                      <input type="text" class="form-control" placeholder="Classroom Training Duration (Weeks)">
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <input type="text" class="form-control" placeholder="Nesting / OJT Duration (Weeks)">
                                                   </div>
                                                </div>
                                                <!-- ==== Authorized Locations Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Authorized Locations</h5>
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Work in Office">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Work from Home">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <!-- ==== Process Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Process Details</h5>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the program segment. <br>Eg. <br> Telecom, Retail etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Industry Segment (Eg : Finance, Retail, Insurance, Banking)">
                                                            <option>Retail</option>
                                                            <option>Telecom</option>
                                                            <option>Fintech</option>
                                                            <option>Bankng</option>
                                                            <option>e-Com</option>
                                                            <option>Insurance</option>
                                                            <option>Health Care</option>
                                                            <option>Customer Service</option>
                                                            <option>Others</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0" style="margin-top:33px;">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                                <!-- <div class="form-group col-lg-3 col-md-4">
                                                   <input type="text" class="form-control" placeholder="Total Training Duration (Weeks)">
                                                   </div> -->
                                             </div>
                                          </div>
                                          <div class="saveChannel text-center mt-4">
                                             <button type="button">Save Chaneel</button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="card">
                              <div class="card-header" id="headingTwo">
                                 <h2 class="mb-0">
                                    <button class="btn btn-link btn-block text-left collapsed d-flex align-items-center justify-content-between" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                       LOB Two
                                       <div class="completion_div">
                                          <small>Completion Percent</small>
                                          <div class="progress">
                                             <div class="progress-bar progress-bar-striped bg-success" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">80%</div>
                                          </div>
                                       </div>
                                    </button>
                                 </h2>
                              </div>
                              <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionAccount1">
                                 <div class="card-body">
                                    <ul class="nav nav-tabs md-tabs boxparent-tabs mb-2" role="tablist">
                                       <li role="presentation" class="nav-item"><a class="active nav-link" href="#channelTab3" aria-controls="channelTab3" role="tab" data-toggle="tab">Channel One</a></li>
                                       <li role="presentation" class="nav-item"><a class="nav-link" href="#channelTab4" aria-controls="channelTab4" role="tab" data-toggle="tab">Channel Two</a></li>
                                    </ul>
                                    <div class="tab-content">
                                       <!-- ================= channel One Tab  ================ -->
                                       <div role="tabpanel" class="tab-pane tabRamp-pane fade show active" id="channelTab3">
                                          <div class="text-left accoutList">
                                             <ul>
                                                <li><strong>Country -</strong> India</li>
                                                <li><strong>City Name -</strong> Pune</li>
                                                <li><strong>Site Name -</strong> Lorum Parum</li>
                                                <li><strong>Language -</strong> English</li>
                                             </ul>
                                          </div>
                                          <!-- ==== Billability ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Billability</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="How is the billing done for the account"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Method">
                                                            <option>Monthly FTE</option>
                                                            <option>Incenter Hours</option>
                                                            <option>Production Hour</option>
                                                            <option>Productive Hour with interval compliance caps</option>
                                                            <option>Handle Minutes</option>
                                                            <option>Per Call</option>
                                                            <option>Per Call Tiered Pricing</option>
                                                            <option>Per Minute with Occupancy Adjustment</option>
                                                            <option>Per Minute with AHT Cap</option>
                                                            <option>Per Minute when only Talk Time and ACW are paid</option>
                                                            <option>Per Minute when only Talk Time and Hold are paid</option>
                                                            <option>Per Minute when only Talk Time is Paid</option>
                                                            <option>Per E-mail Processed</option>
                                                            <option>Per Workstation</option>
                                                            <option>Per Sale</option>
                                                            <option>Per Chat</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the parameter basis which the billing is capped. <br>Eg. <br> AHT @ 300 secs <br> Occ% @ 82%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Cap">
                                                            <option>Occupancy</option>
                                                            <option>AHT</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Enter Value for selected Billing Cap"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Enter Value">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the minimun guarantee for Billing. <br>Eg. <br> 85% of locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Guarantee">
                                                            <option>100%</option>
                                                            <option>95%</option>
                                                            <option>90%</option>
                                                            <option>85%</option>
                                                            <option>80%</option>
                                                            <option>75%</option>
                                                            <option>70%</option>
                                                            <option>65%</option>
                                                            <option>60%</option>
                                                            <option>55%</option>
                                                            <option>50%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the reference parameter for min. guarantee. <br>Eg. <br> 80% of the locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                            <option>Current Run Rate</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the maximum billing. <br>Eg. <br> 110% of locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billable Threshold">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the input parameter for max billing. <br>Eg. <br> 110% of the locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12 col-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== KPIs & Objective ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>KPIs & Objectives</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 1 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 1 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 2 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 2 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Center is liable to staff upto 110% of the Interval / Daily Lock"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="SOW Max Staffing Req?">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Operating Hours ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Operating Hours - <i class="fad fa-info-circle" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="General operating hours of the Programs / LOBs"></i></h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Weekday Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Weekday End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sat Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sat End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sun Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sun End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Employee Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Employee Details</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 40 hrs or as per SOW/Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Full-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 20-30 hrs or as per Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Part-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Seasonal hires, contractual hires"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Contractual Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== System Information ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>System Information</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of the ACD- Avaya, Cisco, Aws etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="ACD Name">
                                                            <option>INCONTACT</option>
                                                            <option>AWS CONNECT</option>
                                                            <option>CISCO</option>
                                                            <option>AVAYA</option>
                                                            <option>GENESYS</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of WFM Scheduling Tool Verint, Nice"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="WFM Tool">
                                                            <option>NICE</option>
                                                            <option>VERINT</option>
                                                            <option>ASPECT</option>
                                                            <option>GENESYS</option>
                                                            <option>CALABRIO</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of Backoffice support tool - Kana, Salesforce"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Back office Tool">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Training, Authorized Locations and Process Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <div class="row">
                                                <!-- ==== Training Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Training Details</h5>
                                                   <div class="form-group mb-4">
                                                      <input type="text" class="form-control" placeholder="Classroom Training Duration (Weeks)">
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <input type="text" class="form-control" placeholder="Nesting / OJT Duration (Weeks)">
                                                   </div>
                                                </div>
                                                <!-- ==== Authorized Locations Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Authorized Locations</h5>
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Work in Office">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Work from Home">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <!-- ==== Process Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Process Details</h5>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the program segment. <br>Eg. <br> Telecom, Retail etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Industry Segment (Eg : Finance, Retail, Insurance, Banking)">
                                                            <option>Retail</option>
                                                            <option>Telecom</option>
                                                            <option>Fintech</option>
                                                            <option>Bankng</option>
                                                            <option>e-Com</option>
                                                            <option>Insurance</option>
                                                            <option>Health Care</option>
                                                            <option>Customer Service</option>
                                                            <option>Others</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0" style="margin-top:33px;">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                                <!-- <div class="form-group col-lg-3 col-md-4">
                                                   <input type="text" class="form-control" placeholder="Total Training Duration (Weeks)">
                                                   </div> -->
                                             </div>
                                          </div>
                                          <div class="saveChannel text-center mt-4">
                                             <button type="button">Save Chaneel</button>
                                          </div>
                                       </div>
                                       <!-- ================= channel Two Tab  ================ -->
                                       <div role="tabpanel" class="tab-pane tabRamp-pane fade" id="channelTab4">
                                          <div class="text-left accoutList">
                                             <ul>
                                                <li><strong>Country -</strong> India</li>
                                                <li><strong>City Name -</strong> Pune</li>
                                                <li><strong>Site Name -</strong> Lorum Parum</li>
                                                <li><strong>Language -</strong> English</li>
                                             </ul>
                                          </div>
                                          <!-- ==== Billability ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Billability</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="How is the billing done for the account"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Method">
                                                            <option>Monthly FTE</option>
                                                            <option>Incenter Hours</option>
                                                            <option>Production Hour</option>
                                                            <option>Productive Hour with interval compliance caps</option>
                                                            <option>Handle Minutes</option>
                                                            <option>Per Call</option>
                                                            <option>Per Call Tiered Pricing</option>
                                                            <option>Per Minute with Occupancy Adjustment</option>
                                                            <option>Per Minute with AHT Cap</option>
                                                            <option>Per Minute when only Talk Time and ACW are paid</option>
                                                            <option>Per Minute when only Talk Time and Hold are paid</option>
                                                            <option>Per Minute when only Talk Time is Paid</option>
                                                            <option>Per E-mail Processed</option>
                                                            <option>Per Workstation</option>
                                                            <option>Per Sale</option>
                                                            <option>Per Chat</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the parameter basis which the billing is capped. <br>Eg. <br> AHT @ 300 secs <br> Occ% @ 82%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Cap">
                                                            <option>Occupancy</option>
                                                            <option>AHT</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Enter Value for selected Billing Cap"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Enter Value">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the minimun guarantee for Billing. <br>Eg. <br> 85% of locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Guarantee">
                                                            <option>100%</option>
                                                            <option>95%</option>
                                                            <option>90%</option>
                                                            <option>85%</option>
                                                            <option>80%</option>
                                                            <option>75%</option>
                                                            <option>70%</option>
                                                            <option>65%</option>
                                                            <option>60%</option>
                                                            <option>55%</option>
                                                            <option>50%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the reference parameter for min. guarantee. <br>Eg. <br> 80% of the locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                            <option>Current Run Rate</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the maximum billing. <br>Eg. <br> 110% of locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billable Threshold">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the input parameter for max billing. <br>Eg. <br> 110% of the locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12 col-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== KPIs & Objective ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>KPIs & Objectives</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 1 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 1 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 2 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 2 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Center is liable to staff upto 110% of the Interval / Daily Lock"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="SOW Max Staffing Req?">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Operating Hours ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Operating Hours - <i class="fad fa-info-circle" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="General operating hours of the Programs / LOBs"></i></h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Weekday Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Weekday End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sat Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sat End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sun Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sun End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Employee Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Employee Details</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 40 hrs or as per SOW/Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Full-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 20-30 hrs or as per Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Part-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Seasonal hires, contractual hires"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Contractual Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== System Information ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>System Information</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of the ACD- Avaya, Cisco, Aws etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="ACD Name">
                                                            <option>INCONTACT</option>
                                                            <option>AWS CONNECT</option>
                                                            <option>CISCO</option>
                                                            <option>AVAYA</option>
                                                            <option>GENESYS</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of WFM Scheduling Tool Verint, Nice"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="WFM Tool">
                                                            <option>NICE</option>
                                                            <option>VERINT</option>
                                                            <option>ASPECT</option>
                                                            <option>GENESYS</option>
                                                            <option>CALABRIO</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of Backoffice support tool - Kana, Salesforce"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Back office Tool">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Training, Authorized Locations and Process Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <div class="row">
                                                <!-- ==== Training Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Training Details</h5>
                                                   <div class="form-group mb-4">
                                                      <input type="text" class="form-control" placeholder="Classroom Training Duration (Weeks)">
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <input type="text" class="form-control" placeholder="Nesting / OJT Duration (Weeks)">
                                                   </div>
                                                </div>
                                                <!-- ==== Authorized Locations Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Authorized Locations</h5>
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Work in Office">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Work from Home">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <!-- ==== Process Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Process Details</h5>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the program segment. <br>Eg. <br> Telecom, Retail etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Industry Segment (Eg : Finance, Retail, Insurance, Banking)">
                                                            <option>Retail</option>
                                                            <option>Telecom</option>
                                                            <option>Fintech</option>
                                                            <option>Bankng</option>
                                                            <option>e-Com</option>
                                                            <option>Insurance</option>
                                                            <option>Health Care</option>
                                                            <option>Customer Service</option>
                                                            <option>Others</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0" style="margin-top:33px;">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                                <!-- <div class="form-group col-lg-3 col-md-4">
                                                   <input type="text" class="form-control" placeholder="Total Training Duration (Weeks)">
                                                   </div> -->
                                             </div>
                                          </div>
                                          <div class="saveChannel text-center mt-4">
                                             <button type="button">Save Chaneel</button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                     <div class="details-container text-left">
                        <div class="d-flex align-items-center justify-content-between mb-3">
                           <h2>Account - <span>Microsoft</span></h2>
                           <button class="cloneBtn" type="button" data-toggle="modal" data-target="#cloneDataModal"><i class="far fa-clone"></i>Clone Data</button>
                        </div>
                        <div class="accordion" id="accordionAccount2">
                           <div class="card">
                              <div class="card-header" id="headingOneM1">
                                 <h2 class="mb-0">
                                    <button class="btn btn-link btn-block text-left collapsed d-flex align-items-center justify-content-between" type="button" data-toggle="collapse" data-target="#collapseOneM1" aria-expanded="false" aria-controls="collapseOneM1">
                                       LOB One
                                       <div class="completion_div">
                                          <small>Completion Percent</small>
                                          <div class="progress">
                                             <div class="progress-bar progress-bar-striped bg-danger" role="progressbar" style="width: 50%" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">50%</div>
                                          </div>
                                       </div>
                                    </button>
                                 </h2>
                              </div>
                              <div id="collapseOneM1" class="collapse" aria-labelledby="headingOneM1" data-parent="#accordionAccount2">
                                 <div class="card-body">
                                    <ul class="nav nav-tabs md-tabs boxparent-tabs mb-2" role="tablist">
                                       <li role="presentation" class="nav-item"><a class="active nav-link" href="#channelTab5" aria-controls="channelTab5" role="tab" data-toggle="tab">Channel One</a></li>
                                       <li role="presentation" class="nav-item"><a class="nav-link" href="#channelTab6" aria-controls="channelTab6" role="tab" data-toggle="tab">Channel Two</a></li>
                                    </ul>
                                    <div class="tab-content">
                                       <!-- ================= channel One Tab  ================ -->
                                       <div role="tabpanel" class="tab-pane tabRamp-pane fade show active" id="channelTab5">
                                          <div class="text-left accoutList">
                                             <ul>
                                                <li><strong>Country -</strong> India</li>
                                                <li><strong>City Name -</strong> Pune</li>
                                                <li><strong>Site Name -</strong> Lorum Parum</li>
                                                <li><strong>Language -</strong> English</li>
                                             </ul>
                                          </div>
                                          <!-- ==== Billability ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Billability</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="How is the billing done for the account"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Method">
                                                            <option>Monthly FTE</option>
                                                            <option>Incenter Hours</option>
                                                            <option>Production Hour</option>
                                                            <option>Productive Hour with interval compliance caps</option>
                                                            <option>Handle Minutes</option>
                                                            <option>Per Call</option>
                                                            <option>Per Call Tiered Pricing</option>
                                                            <option>Per Minute with Occupancy Adjustment</option>
                                                            <option>Per Minute with AHT Cap</option>
                                                            <option>Per Minute when only Talk Time and ACW are paid</option>
                                                            <option>Per Minute when only Talk Time and Hold are paid</option>
                                                            <option>Per Minute when only Talk Time is Paid</option>
                                                            <option>Per E-mail Processed</option>
                                                            <option>Per Workstation</option>
                                                            <option>Per Sale</option>
                                                            <option>Per Chat</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the parameter basis which the billing is capped. <br>Eg. <br> AHT @ 300 secs <br> Occ% @ 82%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Cap">
                                                            <option>Occupancy</option>
                                                            <option>AHT</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Enter Value for selected Billing Cap"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Enter Value">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the minimun guarantee for Billing. <br>Eg. <br> 85% of locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Guarantee">
                                                            <option>100%</option>
                                                            <option>95%</option>
                                                            <option>90%</option>
                                                            <option>85%</option>
                                                            <option>80%</option>
                                                            <option>75%</option>
                                                            <option>70%</option>
                                                            <option>65%</option>
                                                            <option>60%</option>
                                                            <option>55%</option>
                                                            <option>50%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the reference parameter for min. guarantee. <br>Eg. <br> 80% of the locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                            <option>Current Run Rate</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the maximum billing. <br>Eg. <br> 110% of locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billable Threshold">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the input parameter for max billing. <br>Eg. <br> 110% of the locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12 col-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== KPIs & Objective ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>KPIs & Objectives</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 1 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 1 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 2 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 2 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Center is liable to staff upto 110% of the Interval / Daily Lock"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="SOW Max Staffing Req?">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Operating Hours ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Operating Hours - <i class="fad fa-info-circle" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="General operating hours of the Programs / LOBs"></i></h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Weekday Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Weekday End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sat Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sat End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sun Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sun End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Employee Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Employee Details</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 40 hrs or as per SOW/Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Full-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 20-30 hrs or as per Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Part-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Seasonal hires, contractual hires"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Contractual Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== System Information ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>System Information</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of the ACD- Avaya, Cisco, Aws etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="ACD Name">
                                                            <option>INCONTACT</option>
                                                            <option>AWS CONNECT</option>
                                                            <option>CISCO</option>
                                                            <option>AVAYA</option>
                                                            <option>GENESYS</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of WFM Scheduling Tool Verint, Nice"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="WFM Tool">
                                                            <option>NICE</option>
                                                            <option>VERINT</option>
                                                            <option>ASPECT</option>
                                                            <option>GENESYS</option>
                                                            <option>CALABRIO</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of Backoffice support tool - Kana, Salesforce"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Back office Tool">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Training, Authorized Locations and Process Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <div class="row">
                                                <!-- ==== Training Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Training Details</h5>
                                                   <div class="form-group mb-4">
                                                      <input type="text" class="form-control" placeholder="Classroom Training Duration (Weeks)">
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <input type="text" class="form-control" placeholder="Nesting / OJT Duration (Weeks)">
                                                   </div>
                                                </div>
                                                <!-- ==== Authorized Locations Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Authorized Locations</h5>
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Work in Office">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Work from Home">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <!-- ==== Process Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Process Details</h5>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the program segment. <br>Eg. <br> Telecom, Retail etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Industry Segment (Eg : Finance, Retail, Insurance, Banking)">
                                                            <option>Retail</option>
                                                            <option>Telecom</option>
                                                            <option>Fintech</option>
                                                            <option>Bankng</option>
                                                            <option>e-Com</option>
                                                            <option>Insurance</option>
                                                            <option>Health Care</option>
                                                            <option>Customer Service</option>
                                                            <option>Others</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0" style="margin-top:33px;">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                                <!-- <div class="form-group col-lg-3 col-md-4">
                                                   <input type="text" class="form-control" placeholder="Total Training Duration (Weeks)">
                                                   </div> -->
                                             </div>
                                          </div>
                                          <div class="saveChannel text-center mt-4">
                                             <button type="button">Save Chaneel</button>
                                          </div>
                                       </div>
                                       <!-- ================= channel Two Tab  ================ -->
                                       <div role="tabpanel" class="tab-pane tabRamp-pane fade" id="channelTab6">
                                          <div class="text-left accoutList">
                                             <ul>
                                                <li><strong>Country -</strong> India</li>
                                                <li><strong>City Name -</strong> Pune</li>
                                                <li><strong>Site Name -</strong> Lorum Parum</li>
                                                <li><strong>Language -</strong> English</li>
                                             </ul>
                                          </div>
                                          <!-- ==== Billability ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Billability</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="How is the billing done for the account"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Method">
                                                            <option>Monthly FTE</option>
                                                            <option>Incenter Hours</option>
                                                            <option>Production Hour</option>
                                                            <option>Productive Hour with interval compliance caps</option>
                                                            <option>Handle Minutes</option>
                                                            <option>Per Call</option>
                                                            <option>Per Call Tiered Pricing</option>
                                                            <option>Per Minute with Occupancy Adjustment</option>
                                                            <option>Per Minute with AHT Cap</option>
                                                            <option>Per Minute when only Talk Time and ACW are paid</option>
                                                            <option>Per Minute when only Talk Time and Hold are paid</option>
                                                            <option>Per Minute when only Talk Time is Paid</option>
                                                            <option>Per E-mail Processed</option>
                                                            <option>Per Workstation</option>
                                                            <option>Per Sale</option>
                                                            <option>Per Chat</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the parameter basis which the billing is capped. <br>Eg. <br> AHT @ 300 secs <br> Occ% @ 82%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Cap">
                                                            <option>Occupancy</option>
                                                            <option>AHT</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Enter Value for selected Billing Cap"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Enter Value">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the minimun guarantee for Billing. <br>Eg. <br> 85% of locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Guarantee">
                                                            <option>100%</option>
                                                            <option>95%</option>
                                                            <option>90%</option>
                                                            <option>85%</option>
                                                            <option>80%</option>
                                                            <option>75%</option>
                                                            <option>70%</option>
                                                            <option>65%</option>
                                                            <option>60%</option>
                                                            <option>55%</option>
                                                            <option>50%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the reference parameter for min. guarantee. <br>Eg. <br> 80% of the locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                            <option>Current Run Rate</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the maximum billing. <br>Eg. <br> 110% of locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billable Threshold">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the input parameter for max billing. <br>Eg. <br> 110% of the locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12 col-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== KPIs & Objective ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>KPIs & Objectives</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 1 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 1 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 2 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 2 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Center is liable to staff upto 110% of the Interval / Daily Lock"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="SOW Max Staffing Req?">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Operating Hours ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Operating Hours - <i class="fad fa-info-circle" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="General operating hours of the Programs / LOBs"></i></h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Weekday Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Weekday End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sat Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sat End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sun Start Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sun End Time">
                                                         <option>0:00</option>
                                                         <option>0:30</option>
                                                         <option>1:00</option>
                                                         <option>1:30</option>
                                                         <option>2:00</option>
                                                         <option>2:30</option>
                                                         <option>3:00</option>
                                                         <option>3:30</option>
                                                         <option>4:00</option>
                                                         <option>4:30</option>
                                                         <option>5:00</option>
                                                         <option>5:30</option>
                                                         <option>6:00</option>
                                                         <option>6:30</option>
                                                         <option>7:00</option>
                                                         <option>7:30</option>
                                                         <option>8:00</option>
                                                         <option>8:30</option>
                                                         <option>9:00</option>
                                                         <option>9:30</option>
                                                         <option>10:00</option>
                                                         <option>10:30</option>
                                                         <option>11:00</option>
                                                         <option>11:30</option>
                                                         <option>12:00</option>
                                                         <option>12:30</option>
                                                         <option>13:00</option>
                                                         <option>13:30</option>
                                                         <option>14:00</option>
                                                         <option>14:30</option>
                                                         <option>15:00</option>
                                                         <option>15:30</option>
                                                         <option>16:00</option>
                                                         <option>16:30</option>
                                                         <option>17:00</option>
                                                         <option>17:30</option>
                                                         <option>18:00</option>
                                                         <option>18:30</option>
                                                         <option>19:00</option>
                                                         <option>19:30</option>
                                                         <option>20:00</option>
                                                         <option>20:30</option>
                                                         <option>21:00</option>
                                                         <option>21:30</option>
                                                         <option>22:00</option>
                                                         <option>22:30</option>
                                                         <option>23:00</option>
                                                         <option>23:30</option>
                                                         <option>No Operations</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Employee Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Employee Details</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 40 hrs or as per SOW/Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Full-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 20-30 hrs or as per Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Part-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Seasonal hires, contractual hires"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Contractual Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== System Information ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>System Information</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of the ACD- Avaya, Cisco, Aws etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="ACD Name">
                                                            <option>INCONTACT</option>
                                                            <option>AWS CONNECT</option>
                                                            <option>CISCO</option>
                                                            <option>AVAYA</option>
                                                            <option>GENESYS</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of WFM Scheduling Tool Verint, Nice"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="WFM Tool">
                                                            <option>NICE</option>
                                                            <option>VERINT</option>
                                                            <option>ASPECT</option>
                                                            <option>GENESYS</option>
                                                            <option>CALABRIO</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of Backoffice support tool - Kana, Salesforce"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Back office Tool">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Training, Authorized Locations and Process Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <div class="row">
                                                <!-- ==== Training Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Training Details</h5>
                                                   <div class="form-group mb-4">
                                                      <input type="text" class="form-control" placeholder="Classroom Training Duration (Weeks)">
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <input type="text" class="form-control" placeholder="Nesting / OJT Duration (Weeks)">
                                                   </div>
                                                </div>
                                                <!-- ==== Authorized Locations Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Authorized Locations</h5>
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Work in Office">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Work from Home">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <!-- ==== Process Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Process Details</h5>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the program segment. <br>Eg. <br> Telecom, Retail etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Industry Segment (Eg : Finance, Retail, Insurance, Banking)">
                                                            <option>Retail</option>
                                                            <option>Telecom</option>
                                                            <option>Fintech</option>
                                                            <option>Bankng</option>
                                                            <option>e-Com</option>
                                                            <option>Insurance</option>
                                                            <option>Health Care</option>
                                                            <option>Customer Service</option>
                                                            <option>Others</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0" style="margin-top:33px;">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                                <!-- <div class="form-group col-lg-3 col-md-4">
                                                   <input type="text" class="form-control" placeholder="Total Training Duration (Weeks)">
                                                   </div> -->
                                             </div>
                                          </div>
                                          <div class="saveChannel text-center mt-4">
                                             <button type="button">Save Chaneel</button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                           <div class="card">
                              <div class="card-header" id="headingTwoM2">
                                 <h2 class="mb-0">
                                    <button class="btn btn-link btn-block text-left collapsed d-flex align-items-center justify-content-between" type="button" data-toggle="collapse" data-target="#collapseTwoM2" aria-expanded="false" aria-controls="collapseTwoM2">
                                       LOB Two
                                       <div class="completion_div">
                                          <small>Completion Percent</small>
                                          <div class="progress">
                                             <div class="progress-bar progress-bar-striped bg-success" role="progressbar" style="width: 80%" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100">80%</div>
                                          </div>
                                       </div>
                                    </button>
                                 </h2>
                              </div>
                              <div id="collapseTwoM2" class="collapse" aria-labelledby="headingTwoM2" data-parent="#accordionAccount2">
                                 <div class="card-body">
                                    <ul class="nav nav-tabs md-tabs boxparent-tabs mb-2" role="tablist">
                                       <li role="presentation" class="nav-item"><a class="active nav-link" href="#channelTab7" aria-controls="channelTab7" role="tab" data-toggle="tab">Channel One</a></li>
                                       <li role="presentation" class="nav-item"><a class="nav-link" href="#channelTab8" aria-controls="channelTab8" role="tab" data-toggle="tab">Channel Two</a></li>
                                    </ul>
                                    <div class="tab-content">
                                       <!-- ================= channel One Tab  ================ -->
                                       <div role="tabpanel" class="tab-pane tabRamp-pane fade show active" id="channelTab7">
                                          <div class="text-left accoutList">
                                             <ul>
                                                <li><strong>Country -</strong> India</li>
                                                <li><strong>City Name -</strong> Pune</li>
                                                <li><strong>Site Name -</strong> Lorum Parum</li>
                                                <li><strong>Language -</strong> English</li>
                                             </ul>
                                          </div>
                                          <!-- ==== Billability ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Billability</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="How is the billing done for the account"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Method">
                                                            <option>Monthly FTE</option>
                                                            <option>Incenter Hours</option>
                                                            <option>Production Hour</option>
                                                            <option>Productive Hour with interval compliance caps</option>
                                                            <option>Handle Minutes</option>
                                                            <option>Per Call</option>
                                                            <option>Per Call Tiered Pricing</option>
                                                            <option>Per Minute with Occupancy Adjustment</option>
                                                            <option>Per Minute with AHT Cap</option>
                                                            <option>Per Minute when only Talk Time and ACW are paid</option>
                                                            <option>Per Minute when only Talk Time and Hold are paid</option>
                                                            <option>Per Minute when only Talk Time is Paid</option>
                                                            <option>Per E-mail Processed</option>
                                                            <option>Per Workstation</option>
                                                            <option>Per Sale</option>
                                                            <option>Per Chat</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the parameter basis which the billing is capped. <br>Eg. <br> AHT @ 300 secs <br> Occ% @ 82%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Cap">
                                                            <option>Occupancy</option>
                                                            <option>AHT</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Enter Value for selected Billing Cap"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Enter Value">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the minimun guarantee for Billing. <br>Eg. <br> 85% of locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Guarantee">
                                                            <option>100%</option>
                                                            <option>95%</option>
                                                            <option>90%</option>
                                                            <option>85%</option>
                                                            <option>80%</option>
                                                            <option>75%</option>
                                                            <option>70%</option>
                                                            <option>65%</option>
                                                            <option>60%</option>
                                                            <option>55%</option>
                                                            <option>50%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the reference parameter for min. guarantee. <br>Eg. <br> 80% of the locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                            <option>Current Run Rate</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the maximum billing. <br>Eg. <br> 110% of locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billable Threshold">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the input parameter for max billing. <br>Eg. <br> 110% of the locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12 col-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== KPIs & Objective ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>KPIs & Objectives</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 1 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 1 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 2 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 2 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Center is liable to staff upto 110% of the Interval / Daily Lock"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="SOW Max Staffing Req?">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Operating Hours ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Operating Hours - <i class="fad fa-info-circle" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="General operating hours of the Programs / LOBs"></i></h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Weekday Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Weekday End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sat Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sat End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sun Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sun End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Employee Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Employee Details</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 40 hrs or as per SOW/Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Full-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 20-30 hrs or as per Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Part-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Seasonal hires, contractual hires"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Contractual Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== System Information ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>System Information</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of the ACD- Avaya, Cisco, Aws etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="ACD Name">
                                                            <option>INCONTACT</option>
                                                            <option>AWS CONNECT</option>
                                                            <option>CISCO</option>
                                                            <option>AVAYA</option>
                                                            <option>GENESYS</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of WFM Scheduling Tool Verint, Nice"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="WFM Tool">
                                                            <option>NICE</option>
                                                            <option>VERINT</option>
                                                            <option>ASPECT</option>
                                                            <option>GENESYS</option>
                                                            <option>CALABRIO</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of Backoffice support tool - Kana, Salesforce"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Back office Tool">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Training, Authorized Locations and Process Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <div class="row">
                                                <!-- ==== Training Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Training Details</h5>
                                                   <div class="form-group mb-4">
                                                      <input type="text" class="form-control" placeholder="Classroom Training Duration (Weeks)">
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <input type="text" class="form-control" placeholder="Nesting / OJT Duration (Weeks)">
                                                   </div>
                                                </div>
                                                <!-- ==== Authorized Locations Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Authorized Locations</h5>
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Work in Office">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Work from Home">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <!-- ==== Process Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Process Details</h5>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the program segment. <br>Eg. <br> Telecom, Retail etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Industry Segment (Eg : Finance, Retail, Insurance, Banking)">
                                                            <option>Retail</option>
                                                            <option>Telecom</option>
                                                            <option>Fintech</option>
                                                            <option>Bankng</option>
                                                            <option>e-Com</option>
                                                            <option>Insurance</option>
                                                            <option>Health Care</option>
                                                            <option>Customer Service</option>
                                                            <option>Others</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0" style="margin-top:33px;">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                                <!-- <div class="form-group col-lg-3 col-md-4">
                                                   <input type="text" class="form-control" placeholder="Total Training Duration (Weeks)">
                                                   </div> -->
                                             </div>
                                          </div>
                                          <div class="saveChannel text-center mt-4">
                                             <button type="button">Save Chaneel</button>
                                          </div>
                                       </div>
                                       <!-- ================= channel Two Tab  ================ -->
                                       <div role="tabpanel" class="tab-pane tabRamp-pane fade" id="channelTab8">
                                          <div class="text-left accoutList">
                                             <ul>
                                                <li><strong>Country -</strong> India</li>
                                                <li><strong>City Name -</strong> Pune</li>
                                                <li><strong>Site Name -</strong> Lorum Parum</li>
                                                <li><strong>Language -</strong> English</li>
                                             </ul>
                                          </div>
                                          <!-- ==== Billability ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Billability</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="How is the billing done for the account"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Method">
                                                            <option>Monthly FTE</option>
                                                            <option>Incenter Hours</option>
                                                            <option>Production Hour</option>
                                                            <option>Productive Hour with interval compliance caps</option>
                                                            <option>Handle Minutes</option>
                                                            <option>Per Call</option>
                                                            <option>Per Call Tiered Pricing</option>
                                                            <option>Per Minute with Occupancy Adjustment</option>
                                                            <option>Per Minute with AHT Cap</option>
                                                            <option>Per Minute when only Talk Time and ACW are paid</option>
                                                            <option>Per Minute when only Talk Time and Hold are paid</option>
                                                            <option>Per Minute when only Talk Time is Paid</option>
                                                            <option>Per E-mail Processed</option>
                                                            <option>Per Workstation</option>
                                                            <option>Per Sale</option>
                                                            <option>Per Chat</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the parameter basis which the billing is capped. <br>Eg. <br> AHT @ 300 secs <br> Occ% @ 82%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Billing Cap">
                                                            <option>Occupancy</option>
                                                            <option>AHT</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Enter Value for selected Billing Cap"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Enter Value">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the minimun guarantee for Billing. <br>Eg. <br> 85% of locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Guarantee">
                                                            <option>100%</option>
                                                            <option>95%</option>
                                                            <option>90%</option>
                                                            <option>85%</option>
                                                            <option>80%</option>
                                                            <option>75%</option>
                                                            <option>70%</option>
                                                            <option>65%</option>
                                                            <option>60%</option>
                                                            <option>55%</option>
                                                            <option>50%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the reference parameter for min. guarantee. <br>Eg. <br> 80% of the locked forecast"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Min Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                            <option>Current Run Rate</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Specify the maximum billing. <br>Eg. <br> 110% of locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billable Threshold">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the input parameter for max billing. <br>Eg. <br> 110% of the locked FTE"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Max Billing Reference">
                                                            <option>Contractual Lock</option>
                                                            <option>Contractual FTE</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12 col-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== KPIs & Objective ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>KPIs & Objectives</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 1 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 1 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Agreed KPI metrics as per SOW. <br>Eg. <br> 80/30 Service Level <br> Abandoned < 5%"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Service KPI - 2 (If applicable)">
                                                            <option>Service Level</option>
                                                            <option>ASA</option>
                                                            <option>Abandon %</option>
                                                            <option>Answered %</option>
                                                            <option>Handle to Commit %</option>
                                                            <option>FTE Delivery</option>
                                                            <option>Production Hours</option>
                                                            <option>Occupancy %</option>
                                                            <option>Interval Compliance %</option>
                                                            <option>ISAR Delivery</option>
                                                            <option>Service Quality Index</option>
                                                            <option>AHT</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Please clearly write exact description of the target <br>e.g.<br> 80% in 20 Sec"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Service KPI - 2 - Target (%/Sec)">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Center is liable to staff upto 110% of the Interval / Daily Lock"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="SOW Max Staffing Req?">
                                                            <option>120%</option>
                                                            <option>119%</option>
                                                            <option>118%</option>
                                                            <option>117%</option>
                                                            <option>116%</option>
                                                            <option>115%</option>
                                                            <option>114%</option>
                                                            <option>113%</option>
                                                            <option>112%</option>
                                                            <option>111%</option>
                                                            <option>110%</option>
                                                            <option>109%</option>
                                                            <option>108%</option>
                                                            <option>107%</option>
                                                            <option>106%</option>
                                                            <option>105%</option>
                                                            <option>104%</option>
                                                            <option>103%</option>
                                                            <option>102%</option>
                                                            <option>101%</option>
                                                            <option>Not Applicable</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Operating Hours ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Operating Hours - <i class="fad fa-info-circle" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="General operating hours of the Programs / LOBs"></i></h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Weekday Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Weekday End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sat Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sat End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Sun Start Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Sun End Time">
                                                         <option>Option 1</option>
                                                         <option>Option 2</option>
                                                         <option>Option 3</option>
                                                         <option>Option 4</option>
                                                         <option>Option 5</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark" style="height:118px;"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Employee Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>Employee Details</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 40 hrs or as per SOW/Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Full-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="1 FTE = 20-30 hrs or as per Labor Law"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Part-Time Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Seasonal hires, contractual hires"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Contractual Employees">
                                                            <option>Yes</option>
                                                            <option>No</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== System Information ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <h5>System Information</h5>
                                             <div class="row">
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of the ACD- Avaya, Cisco, Aws etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="ACD Name">
                                                            <option>INCONTACT</option>
                                                            <option>AWS CONNECT</option>
                                                            <option>CISCO</option>
                                                            <option>AVAYA</option>
                                                            <option>GENESYS</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of WFM Scheduling Tool Verint, Nice"><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="WFM Tool">
                                                            <option>NICE</option>
                                                            <option>VERINT</option>
                                                            <option>ASPECT</option>
                                                            <option>GENESYS</option>
                                                            <option>CALABRIO</option>
                                                            <option>Other</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Name of Backoffice support tool - Kana, Salesforce"><i class="far fa-info-circle"></i></button>
                                                         <input type="text" class="form-control" placeholder="Back office Tool">
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                          <!-- ==== Training, Authorized Locations and Process Details ==== -->
                                          <div class="accountDetailForm text-left mt-5">
                                             <div class="row">
                                                <!-- ==== Training Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Training Details</h5>
                                                   <div class="form-group mb-4">
                                                      <input type="text" class="form-control" placeholder="Classroom Training Duration (Weeks)">
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <input type="text" class="form-control" placeholder="Nesting / OJT Duration (Weeks)">
                                                   </div>
                                                </div>
                                                <!-- ==== Authorized Locations Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Authorized Locations</h5>
                                                   <div class="form-group mb-4">
                                                      <select class="selectpicker form-control" title="Work in Office">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                   <div class="form-group mb-0">
                                                      <select class="selectpicker form-control" title="Work from Home">
                                                         <option>Yes</option>
                                                         <option>No</option>
                                                      </select>
                                                   </div>
                                                </div>
                                                <!-- ==== Process Details ==== -->
                                                <div class="col col-lg-3 col-md-4 col-12">
                                                   <h5>Process Details</h5>
                                                   <div class="form-group mb-0">
                                                      <div class="fg-control">
                                                         <button type="button" class="infoButton" data-toggle="popover" data-trigger="hover" data-placement="bottom" data-content="Select the program segment. <br>Eg. <br> Telecom, Retail etc."><i class="far fa-info-circle"></i></button>
                                                         <select class="selectpicker form-control" title="Industry Segment (Eg : Finance, Retail, Insurance, Banking)">
                                                            <option>Retail</option>
                                                            <option>Telecom</option>
                                                            <option>Fintech</option>
                                                            <option>Bankng</option>
                                                            <option>e-Com</option>
                                                            <option>Insurance</option>
                                                            <option>Health Care</option>
                                                            <option>Customer Service</option>
                                                            <option>Others</option>
                                                         </select>
                                                      </div>
                                                   </div>
                                                </div>
                                                <div class="col col-lg-3 col-md-12">
                                                   <div class="form-group mb-0" style="margin-top:33px;">
                                                      <textarea class="form-control" placeholder="Remark"></textarea>
                                                   </div>
                                                </div>
                                                <!-- <div class="form-group col-lg-3 col-md-4">
                                                   <input type="text" class="form-control" placeholder="Total Training Duration (Weeks)">
                                                   </div> -->
                                             </div>
                                          </div>
                                          <div class="saveChannel text-center mt-4">
                                             <button type="button">Save Chaneel</button>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="footerBtn-panel">
                     <button type="button" class="action-button previous previous_button">Back</button>
                     <button type="button" class="next action-button">Save & Continue</button>
                  </div>
               </div>
            </fieldset>
            <!-- ========= Process Information Tab ======= -->
            <fieldset class="fielset_panel fielset_height">
               <div class="scrollbarbar">
                  <div class="container" style="position:relative;">
                     <div class="row">
                        <div class="col-lg-3 col-md-6 mb-4">
                           <div class="form-group">
                              <select class="selectpicker form-control" title="Select Account Name">
                                 <option>Apple</option>
                                 <option>Microsoft</option>
                                 <option>Jio</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-6 mb-4">
                           <div class="form-group">
                              <select class="selectpicker form-control" title="Select LOB" multiple>
                                 <option>LOB 1</option>
                                 <option>LOB 2</option>
                                 <option>LOB 3</option>
                                 <option>LOB 4</option>
                                 <option>LOB 5</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-6 mb-4">
                           <div class="form-group">
                              <select class="selectpicker form-control" title="Select Channels" multiple>
                                 <option>Voice - IB</option>
                                 <option>Voice - OB</option>
                                 <option>Chat</option>
                                 <option>Email</option>
                                 <option>Back Office</option>
                                 <option>Social Media</option>
                                 <option>Other</option>
                              </select>
                           </div>
                        </div>
                        <div class="col-lg-3 col-md-6 mb-4">
                           <div class="form-group">
                              <select class="selectpicker form-control" title="Select Country">
                                 <option>Afghanistan</option>
                                 <option>Albania</option>
                                 <option>Algeria</option>
                                 <option>Andorra</option>
                                 <option>Angola</option>
                                 <option>Antigua and Barbuda</option>
                                 <option>Argentina</option>
                                 <option>Armenia</option>
                                 <option>Australia</option>
                                 <option>Austria</option>
                                 <option>Azerbaijan</option>
                                 <option>Bahamas</option>
                                 <option>Bahrain</option>
                                 <option>Bangladesh</option>
                                 <option>Barbados</option>
                                 <option>Belarus</option>
                                 <option>Belgium</option>
                                 <option>Belize</option>
                                 <option>Benin</option>
                                 <option>Bhutan</option>
                                 <option>Bolivia</option>
                              </select>
                           </div>
                        </div>
                     </div>
                     <div class="row">
                        <div class="col col-md-12">
                           <div class="processTableForm generalTableForm">
                              <div class="table-responsive">
                                 <table class="table">
                                    <!-- ======= Forecasting  ======= -->
                                    <tbody>
                                       <tr>
                                          <th colspan="2" class="bg_th">Forecasting</th>
                                       </tr>
                                       <tr>
                                          <td>Which Forecasting tool / software package is being utilised?</td>
                                          <td>
                                             <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Please Enter">
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Which Forecasting model is being used?</td>
                                          <td>
                                             <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Please Enter">
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>What are the key input parameters to the model?</td>
                                          <td>
                                             <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Please Enter">
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>How frequently is the model revisited for goodness of fit?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Monthly</option>
                                                   <option>Quarterly</option>
                                                   <option>Half-yearly</option>
                                                   <option>Yearly</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>How do you measure the accuracy of your Forecasting model?</td>
                                          <td>
                                             <div class="form-group">
                                                <input type="text" class="form-control" placeholder="Please Enter">
                                             </div>
                                          </td>
                                       </tr>
                                    </tbody>
                                    <!-- ========= Staffing / Resource Planning  ======= -->
                                    <tbody>
                                       <tr>
                                          <th colspan="2" class="bg_th">Staffing / Resource Planning</th>
                                       </tr>
                                       <!-- Forecast Locks -->
                                       <tr>
                                          <th colspan="2">Forecast Locks</th>
                                       </tr>
                                       <tr>
                                          <td>Who provides the Forecast / Lock which forms the base of Staff Planning?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Client</option>
                                                   <option>Internal</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>What is your staff locking model?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>FTE</option>
                                                   <option>Incenter Hours</option>
                                                   <option>Production Hours</option>
                                                   <option>Handle Minutes</option>
                                                   <option>Calls</option>
                                                   <option>Emails</option>
                                                   <option>Chats</option>
                                                   <option>Workstations</option>
                                                   <option>Social Media</option>
                                                   <option>Other</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you generate Internal Forecast?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                   <option>Not Applicable</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Which Forecast is used for Staff Planning?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Client Forecast</option>
                                                   <option>Internal Forecast</option>
                                                   <option>Not Applicable</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <!-- AHT -->
                                       <tr>
                                          <th colspan="2">AHT</th>
                                       </tr>
                                       <tr>
                                          <td>What AHT is used for Staff Planning?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Target-Internal</option>
                                                   <option>Target-Client</option>
                                                   <option>Billable-Cap</option>
                                                   <option>Trend-Based</option>
                                                   <option>Not Applicable</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>How do you calculate New Hire impact on the AHT?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Not Considered</option>
                                                   <option>Experiential</option>
                                                   <option>Calculation (Learning Curve)</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <!-- FTE -->
                                       <tr>
                                          <th colspan="2">FTE</th>
                                       </tr>
                                       <tr>
                                          <td>How do you generate FTE requirements?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Client-Provided</option>
                                                   <option>Workload Fn</option>
                                                   <option>Erlang</option>
                                                   <option>Simulation-Based</option>
                                                   <option>Other</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <!-- In-Office Shrinkage -->
                                       <tr>
                                          <th colspan="2">In-Office Shrinkage</th>
                                       </tr>
                                       <tr>
                                          <td>At what level are your In-Office Shrinkages planned?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>All Combined</option>
                                                   <option>By Aux-code</option>
                                                   <option>By Activity-code</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you have set targets for each individual Aux/Activity code?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                   <option>Not Applicable</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>In-Office shrinkage Forecasts are modeled on (please select the appropriate)</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Trend</option>
                                                   <option>Targets</option>
                                                   <option>Operational-Commitments</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <!-- Out-of-Office Shrinkage -->
                                       <tr>
                                          <th colspan="2">Out-of-Office Shrinkage</th>
                                       </tr>
                                       <tr>
                                          <td>At what level are your Out-of-Office Shrinkages planned?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>All Combined</option>
                                                   <option>By Absence Codes</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Vacation Forecasts are modeled on (please select the appropriate)</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Targets</option>
                                                   <option>Trends</option>
                                                   <option>Modulated (Need-Based)</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Absenteeism Forecasts are modeled on (please select the appropriate)</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Targets</option>
                                                   <option>Trends</option>
                                                   <option>Trend & Seasonality</option>
                                                   <option>Operational Commitments</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <!-- Schedule Inflex -->
                                       <tr>
                                          <th colspan="2">Schedule Inflex</th>
                                       </tr>
                                       <tr>
                                          <td>Is Schedule Inflex considered in Staff planning?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>How is the Schedule Inflex estimated / calculated?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Experiential</option>
                                                   <option>Schedule Simulation</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <!-- Attrition -->
                                       <tr>
                                          <th colspan="2">Attrition</th>
                                       </tr>
                                       <tr>
                                          <td>How do you factor attrition in your staff plan?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Targets</option>
                                                   <option>Trends</option>
                                                   <option>Trend & Seasonality</option>
                                                   <option>Operational Commitments</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you plan for Involuntary Attrition as a separate line item? (BQM, Promotions, Transfers etc.)</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <!-- Staff Planning Connects -->
                                       <tr>
                                          <th colspan="2">Staff Planning Connects</th>
                                       </tr>
                                       <tr>
                                          <td>Do you have Inter-departmental Staff planning discussions?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>What is the frequency?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Weekly</option>
                                                   <option>Bi-weekly</option>
                                                   <option>Monthly</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td colspan="2"><strong>Who decides the below:-</strong></td>
                                       </tr>
                                       <tr>
                                          <td>Staffing Plan (Validation & Signing off key assumptions such as AHT, Shrinkage etc.</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Operations</option>
                                                   <option>WFM</option>
                                                   <option>Client</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Adding Batches</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Operations</option>
                                                   <option>WFM</option>
                                                   <option>Client</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Removing Batches</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Operations</option>
                                                   <option>WFM</option>
                                                   <option>Client</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Cross Skilling</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Operations</option>
                                                   <option>WFM</option>
                                                   <option>Client</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Is there a client dependency for hiring batches?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you have a calibration calls with the Recruitment team</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>If Yes – Weekly or Monthly</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Weekly</option>
                                                   <option>Bi-weekly</option>
                                                   <option>Monthly</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                    </tbody>
                                    <!-- ========= Scheduling  ======= -->
                                    <tbody>
                                       <tr>
                                          <th colspan="2" class="bg_th">Scheduling</th>
                                       </tr>
                                       <tr>
                                          <td>Do you do Call Curve Analysis before deciding the Schedule Pattern?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>What is the frequency of the above?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Monthly</option>
                                                   <option>Quarterly</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>How do you create interval level Volume and AHT requirements?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Monthly</option>
                                                   <option>Quarterly</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>How do you manage the Headcount reconciliation process?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Employee Database - Internal</option>
                                                   <option>Employee Database - Client</option>
                                                   <option>Weekly Inputs from Operations</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you run Manpower Dimensionioning exercise frequently to arrive at optimal HC mix (FT/PT/Split/Flexi?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>What is the frequency of the above?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Weekly</option>
                                                   <option>Bi-weekly</option>
                                                   <option>Monthly</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you run & test different Schedule Patterns to identify best fit?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>What is the frequency of the above?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Weekly</option>
                                                   <option>Bi-weekly</option>
                                                   <option>Monthly</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you plot all In-office shrinkages in your Schedules at Interval Level? (Coaching, Team Meeting, Business Updates etc.)</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                   <option>Not Applicable</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you plot Out-of-Office shrinkage in your Schedules at Interval Level? (Vacation)</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                   <option>Not Applicable</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you review IDP/Schedule deviation prior to schedule release?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you measure Schedule Efficiency?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>What is your target for Schedule Efficiency? (Please specify in %)</td>
                                          <td>
                                             <div class="form-group">
                                                <input type="text" class="form-control">
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>How do you measure the Schedule Efficiency?</td>
                                          <td>
                                             <div class="form-group">
                                                <input type="text" class="form-control">
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>What is your internal target for Scheduling accuracy? (Requirment to Scheduled - Day/Intervals)</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option> &lt; 50%</option>
                                                   <option>50% to 75%</option>
                                                   <option>75% to 90%</option>
                                                   <option> &gt; 90%</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>How do you measure the Schedule Accuracy?</td>
                                          <td>
                                             <div class="form-group">
                                                <input type="text" class="form-control">
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Do you measure the impact of various Scheduling Constraints on the account in terms or FTE & Cost?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                    </tbody>
                                    <!-- ========= Intraday Management  ======= -->
                                    <tbody>
                                       <tr>
                                          <th colspan="2" class="bg_th">Intraday Management</th>
                                       </tr>
                                       <tr>
                                          <td>Do you have a WFM Play book / Guide? E.g - Downtime Process, Calling Tree, Threshold & Skilling</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Does RTA have a daily read out call / RCA?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Does the RTA do real time skill management?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>Does RTA do Intra-day Reforecasting?</td>
                                          <td>
                                             <div class="form-group">
                                                <select class="selectpicker form-control" title="Please select">
                                                   <option>Yes</option>
                                                   <option>No</option>
                                                </select>
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>How do you manage customers resources up or down Realtime?</td>
                                          <td>
                                             <div class="form-group">
                                                <input type="text" class="form-control">
                                             </div>
                                          </td>
                                       </tr>
                                       <tr>
                                          <td>How do you manage and report, variance to plan Realtime?</td>
                                          <td>
                                             <div class="form-group">
                                                <input type="text" class="form-control">
                                             </div>
                                          </td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                           <div class="saveChannel text-center mt-5">
                              <button type="button">Save & Clear</button>
                           </div>
                        </div>
                     </div>
                    
                  </div>
                  <div class="footerBtn-panel">
                     <button type="button" class="action-button previous previous_button">Back</button>
                     <button type="button" class="next action-button">Save & Continue</button>
                  </div>
               </div>
            </fieldset>
            <!-- ========= Files Information Tab ======= -->
            <fieldset class="fielset_panel fielset_height">
               <div class="scrollbarbar">
                  <div class="container">
                     <div class="row d-flex align-items-center justify-content-center">
                        <div class="col col-lg-8 col-12">
                           <div class="accordion" id="accordionFileUpload">
                              <div class="card">
                                 <div class="card-header" id="headingF1">
                                    <h2 class="mb-0">
                                       <button class="btn btn-link btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseF1" aria-expanded="true" aria-controls="collapseF1">Apple</button>
                                    </h2>
                                 </div>
                                 <div id="collapseF1" class="collapse show" aria-labelledby="headingF1" data-parent="#accordionFileUpload">
                                    <div class="card-body">
                                       <div class="table-resposive">
                                          <table class="table table-striped custom-table mb-0 table-data leave_table" id="DataLeaves_Table_0" cellspacing="0" width="100%">
                                             <thead>
                                                <tr>
                                                   <th>File Name</th>
                                                   <th class="text-right">Actions</th>
                                                   <th class="text-center">Status</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td colspan="3">Forecasting</td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Process Document</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Model Sample File</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Accuracy Measurement / Result</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td colspan="3">Staffing / Resource Planning</td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Process Document</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Model Sample File</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Staffing Forecast Accuracy Result</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td colspan="3">Scheduling</td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Process Document</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Scheduling Model (only if done in Excel)</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Scheduling Forecast Accuracy Result</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">IDP / Deviation File sample</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td colspan="3">RTA / Intraday Management</td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Process Document</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Intraday Report Sample</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Day-End Report Sample</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">RCA / Post-Mortem Report Sample</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="card">
                                 <div class="card-header" id="headingF2">
                                    <h2 class="mb-0">
                                       <button class="btn btn-link btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseF2" aria-expanded="false" aria-controls="collapseF2">Microsoft</button>
                                    </h2>
                                 </div>
                                 <div id="collapseF2" class="collapse" aria-labelledby="headingF2" data-parent="#accordionFileUpload">
                                    <div class="card-body">
                                       <div class="table-resposive">
                                          <table class="table table-striped custom-table mb-0 table-data leave_table" id="DataLeaves_Table_0" cellspacing="0" width="100%">
                                             <thead>
                                                <tr>
                                                   <th>File Name</th>
                                                   <th class="text-right">Actions</th>
                                                   <th class="text-center">Status</th>
                                                </tr>
                                             </thead>
                                             <tbody>
                                                <tr>
                                                   <td colspan="3">Forecasting</td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Process Document</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Model Sample File</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Accuracy Measurement / Result</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td colspan="3">Staffing / Resource Planning</td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Process Document</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Model Sample File</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Staffing Forecast Accuracy Result</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td colspan="3">Scheduling</td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Process Document</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Scheduling Model (only if done in Excel)</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Scheduling Forecast Accuracy Result</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">IDP / Deviation File sample</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td colspan="3">RTA / Intraday Management</td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Process Document</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Intraday Report Sample</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">Day-End Report Sample</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                                <tr>
                                                   <td class="text-right">RCA / Post-Mortem Report Sample</td>
                                                   <td class="text-center">
                                                      <button class="fileUploadBtn"><i class="far fa-upload"></i><input type="file" name="myfile" class="file_upload" /></button>
                                                   </td>
                                                   <td class="text-center">
                                                      <div class="dropdown action-label">
                                                         <a class="dropdown-toggle status_leaves" href="#" role="button" data-toggle="dropdown" aria-expanded="false">
                                                         <i class="fa fa-dot-circle-o text-success"></i> Pending
                                                         </a>
                                                         <div class="dropdown-menu dropdown-menu-right">
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-purple"></i> Uploaded</a>
                                                            <a class="dropdown-item" href="#"><i class="fa fa-dot-circle-o text-info"></i> Pending</a>
                                                         </div>
                                                      </div>
                                                   </td>
                                                </tr>
                                             </tbody>
                                          </table>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="footerBtn-panel">
                     <button type="button" class="action-button previous previous_button">Back</button>
                     <button type="button" class="next action-button">Save & Continue</button>
                  </div>
               </div>
            </fieldset>
            <!-- ========= Summary Details Tab ======= -->
            <fieldset class="fielset_panel fielset_height">
               <div class="scrollbarbar">
                  <div class="container">
                     <div class="row">
                        <div class="col col-12">
                           <!-- === Account Details Blocks === -->
                           <div class="summary_contaienr">
                              <h2>Account Details</h2>
                              <ul class="summary_ul">
                                 <li>
                                    <label>User Name</label>
                                    <p>John Doe</p>
                                 </li>
                                 <li>
                                    <label>Business Email</label>
                                    <p>johndoe@demo.com</p>
                                 </li>
                              </ul>
                           </div>
                           <!-- === General Overview Blocks === -->
                           <div class="summary_contaienr">
                              <h2>General Overview</h2>
                              <div class="table-responsive">
                                 <table class="table table-bordered summary_table">
                                    <thead>
                                       <tr>
                                          <th scope="col" class="bg_dark_th">Account Name</th>
                                          <th scope="col" class="bg_dark_th">LOB</th>
                                          <th scope="col" class="bg_dark_th">Channels</th>
                                          <th scope="col" class="bg_dark_th">Country</th>
                                          <th scope="col" class="bg_dark_th">City Name</th>
                                          <th scope="col" class="bg_dark_th">Site Name</th>
                                          <th scope="col" class="bg_dark_th">FTEs</th>
                                       </tr>
                                    </thead>
                                    <tbody>
                                       <tr>
                                          <th rowspan="4">Apple</th>
                                          <td rowspan="2">Chat LOB</td>
                                          <td>Chat</td>
                                          <td>India</td>
                                          <td>Pune</td>
                                          <td>Site Pune</td>
                                          <td>200</td>
                                       </tr>
                                       <tr>
                                          <td>Email</td>
                                          <td>India</td>
                                          <td>Pune</td>
                                          <td>Site Pune</td>
                                          <td>100</td>
                                       </tr>
                                       <tr>
                                          <td rowspan="2">Voice LOB</td>
                                          <td>Voice - IB</td>
                                          <td>India</td>
                                          <td>Pune</td>
                                          <td>Site Pune</td>
                                          <td>50</td>
                                       </tr>
                                       <tr>
                                          <td>Voice - OB</td>
                                          <td>India</td>
                                          <td>Mumbai</td>
                                          <td>Site Mumbai</td>
                                          <td>250</td>
                                       </tr>
                                    </tbody>
                                    <tbody>
                                       <tr>
                                          <th rowspan="4">Microsoft</th>
                                          <td rowspan="2">Chat LOB</td>
                                          <td>Chat</td>
                                          <td>India</td>
                                          <td>Bangalore</td>
                                          <td>Site Bangalore</td>
                                          <td>100</td>
                                       </tr>
                                       <tr>
                                          <td>Email</td>
                                          <td>India</td>
                                          <td>Bangalore</td>
                                          <td>Site Bangalore</td>
                                          <td>150</td>
                                       </tr>
                                       <tr>
                                          <td rowspan="2">Voice LOB</td>
                                          <td>Voice - IB</td>
                                          <td>India</td>
                                          <td>Bangalore</td>
                                          <td>Site Bangalore</td>
                                          <td>70</td>
                                       </tr>
                                       <tr>
                                          <td>Voice - OB</td>
                                          <td>India</td>
                                          <td>Noida</td>
                                          <td>Site Noida</td>
                                          <td>170</td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                           <!-- === Detailed Information Blocks === -->
                           <div class="summary_contaienr">
                              <h2>Detailed Information</h2>
                              <div class="table-responsive">
                                 <table class="table table-bordered summary_table">
                                    <!-- === Account Tbody ===  -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Account Name</th>
                                          <td colspan="4" class="text-center">Apple</td>
                                          <td colspan="4" class="text-center">Microsoft</td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">LOB</th>
                                          <td colspan="2" class="text-center">Chat LOB</td>
                                          <td colspan="2" class="text-center">Voice LOB</td>
                                          <td colspan="2" class="text-center">Chat LOB</td>
                                          <td colspan="2" class="text-center">Voice LOB</td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">Channels</th>
                                          <td class="text-center">Chat</td>
                                          <td class="text-center">Email</td>
                                          <td class="text-center">Voice - IB</td>
                                          <td class="text-center">Voice - OB</td>
                                          <td class="text-center">Chat</td>
                                          <td class="text-center">Email</td>
                                          <td class="text-center">Voice - IB</td>
                                          <td class="text-center">Voice - OB</td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">Country</th>
                                          <td class="text-center">India</td>
                                          <td class="text-center">India</td>
                                          <td class="text-center">India</td>
                                          <td class="text-center">India</td>
                                          <td class="text-center">India</td>
                                          <td class="text-center">India</td>
                                          <td class="text-center">India</td>
                                          <td class="text-center">India</td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">City Name</th>
                                          <td class="text-center">Pune</td>
                                          <td class="text-center">Pune</td>
                                          <td class="text-center">Pune</td>
                                          <td class="text-center">Mumbai</td>
                                          <td class="text-center">Bangalore</td>
                                          <td class="text-center">Bangalore</td>
                                          <td class="text-center">Bangalore</td>
                                          <td class="text-center">Noida</td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">Site Name</th>
                                          <td class="text-center">Site Pune</td>
                                          <td class="text-center">Site Pune</td>
                                          <td class="text-center">Site Pune</td>
                                          <td class="text-center">Site Mumbai</td>
                                          <td class="text-center">Site Bangalore</td>
                                          <td class="text-center">Site Bangalore</td>
                                          <td class="text-center">Site Bangalore</td>
                                          <td class="text-center">Site Noida</td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">FTEs</th>
                                          <td class="text-center">200</td>
                                          <td class="text-center">100</td>
                                          <td class="text-center">50</td>
                                          <td class="text-center">250</td>
                                          <td class="text-center">100</td>
                                          <td class="text-center">150</td>
                                          <td class="text-center">70</td>
                                          <td class="text-center">170</td>
                                       </tr>
                                    </tbody>
                                    <!-- === Billability Tbody ===  -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Billability</th>
                                          <td colspan="8"></td>
                                       </tr>
                                       <tr>
                                          <th>Billing Method</th>
                                          <td class="text-center">Handle Minutes</td>
                                          <td class="text-center">Production Hour</td>
                                          <td class="text-center">Handle Minutes</td>
                                          <td class="text-center">Production Hour</td>
                                          <td class="text-center">Handle Minutes</td>
                                          <td class="text-center">Production Hour</td>
                                          <td class="text-center">Handle Minutes</td>
                                          <td class="text-center">Production Hour</td>
                                       </tr>
                                       <tr>
                                          <th>Billing Cap</th>
                                          <td class="text-center">Occupancy</td>
                                          <td class="text-center">AHT</td>
                                          <td class="text-center">Occupancy</td>
                                          <td class="text-center">AHT</td>
                                          <td class="text-center">Occupancy</td>
                                          <td class="text-center">AHT</td>
                                          <td class="text-center">Occupancy</td>
                                          <td class="text-center">AHT</td>
                                       </tr>
                                       <tr>
                                          <th>Value for selected Billing Cap</th>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                       </tr>
                                       <tr>
                                          <th>Min Billing Guarantee</th>
                                          <td class="text-center">50.%</td>
                                          <td class="text-center">60.%</td>
                                          <td class="text-center">70.%</td>
                                          <td class="text-center">80.%</td>
                                          <td class="text-center">85.%</td>
                                          <td class="text-center">90.%</td>
                                          <td class="text-center">95.%</td>
                                          <td class="text-center">100%</td>
                                       </tr>
                                       <tr>
                                          <th>Min Billing Reference</th>
                                          <td class="text-center">Contractual Lock</td>
                                          <td class="text-center">Contractual FTE</td>
                                          <td class="text-center">Contractual Lock</td>
                                          <td class="text-center">Contractual FTE</td>
                                          <td class="text-center">Contractual Lock</td>
                                          <td class="text-center">Contractual FTE</td>
                                          <td class="text-center">Contractual Lock</td>
                                          <td class="text-center">Contractual FTE</td>
                                       </tr>
                                       <tr>
                                          <th>Max Billable Threshold</th>
                                          <td class="text-center">101.%</td>
                                          <td class="text-center">102.%</td>
                                          <td class="text-center">103.%</td>
                                          <td class="text-center">104.%</td>
                                          <td class="text-center">105.%</td>
                                          <td class="text-center">106.%</td>
                                          <td class="text-center">107.%</td>
                                          <td class="text-center">108.%</td>
                                       </tr>
                                       <tr>
                                          <th>Max Billing Reference</th>
                                          <td class="text-center">Contractual Lock</td>
                                          <td class="text-center">Contractual FTE</td>
                                          <td class="text-center">Contractual Lock</td>
                                          <td class="text-center">Contractual FTE</td>
                                          <td class="text-center">Contractual Lock</td>
                                          <td class="text-center">Contractual FTE</td>
                                          <td class="text-center">Contractual Lock</td>
                                          <td class="text-center">Contractual FTE</td>
                                       </tr>
                                    </tbody>
                                    <!-- === KPIs & Objectives Tbody ===  -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">KPIs & Objectives</th>
                                          <td colspan="8"></td>
                                       </tr>
                                       <tr>
                                          <th>SOW Max Staffing Req?</th>
                                          <td class="text-center">101.%</td>
                                          <td class="text-center">102.%</td>
                                          <td class="text-center">103.%</td>
                                          <td class="text-center">104.%</td>
                                          <td class="text-center">105.%</td>
                                          <td class="text-center">106.%</td>
                                          <td class="text-center">107.%</td>
                                          <td class="text-center">108.%</td>
                                       </tr>
                                       <tr>
                                          <th>Service KPI - 1 (If applicable)</th>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                       </tr>
                                       <tr>
                                          <th>Service KPI - 1 - Target (%/Sec)</th>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                       </tr>
                                       <tr>
                                          <th>Service KPI - 2 (If applicable)</th>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                          <td class="text-center">Occupancy %</td>
                                       </tr>
                                       <tr>
                                          <th>Service KPI - 2 - Target (%/Sec)</th>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                          <td class="text-center">30</td>
                                       </tr>
                                    </tbody>
                                    <!-- === Training Details Tbody ===  -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Training Details</th>
                                          <td colspan="8"></td>
                                       </tr>
                                       <tr>
                                          <th>Classroom Training Duration (Weeks)</th>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                       </tr>
                                       <tr>
                                          <th>Nesting / OJT Duration (Weeks)</th>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                          <td class="text-center">3</td>
                                       </tr>
                                    </tbody>
                                    <!-- === Operating Hours Tbody ===  -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Operating Hours</th>
                                          <td colspan="8"></td>
                                       </tr>
                                       <tr>
                                          <th>Weekday Start Time</th>
                                          <td class="text-center">00:00</td>
                                          <td class="text-center">00:00</td>
                                          <td class="text-center">00:00</td>
                                          <td class="text-center">00:00</td>
                                          <td class="text-center">00:00</td>
                                          <td class="text-center">00:00</td>
                                          <td class="text-center">00:00</td>
                                          <td class="text-center">00:00</td>
                                       </tr>
                                       <tr>
                                          <th>Weekday End Time</th>
                                          <td class="text-center">23:30</td>
                                          <td class="text-center">23:30</td>
                                          <td class="text-center">23:30</td>
                                          <td class="text-center">23:30</td>
                                          <td class="text-center">23:30</td>
                                          <td class="text-center">23:30</td>
                                          <td class="text-center">23:30</td>
                                          <td class="text-center">23:30</td>
                                       </tr>
                                       <tr>
                                          <th>Sat Start Time</th>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                       </tr>
                                       <tr>
                                          <th>Sat Start Time</th>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                       </tr>
                                       <tr>
                                          <th>Sun Start Time</th>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                       </tr>
                                       <tr>
                                          <th>Sun Start Time</th>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                          <td class="text-center">No Operations</td>
                                       </tr>
                                    </tbody>
                                    <!-- === Process Details Tbody ===  -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Process Details</th>
                                          <td colspan="8"></td>
                                       </tr>
                                       <tr>
                                          <th>Industry Segment</th>
                                          <td class="text-center">Fintech</td>
                                          <td class="text-center">Retail</td>
                                          <td class="text-center">Banking</td>
                                          <td class="text-center">e-Com</td>
                                          <td class="text-center">Health Care</td>
                                          <td class="text-center">Telecom</td>
                                          <td class="text-center">Customer Service</td>
                                          <td class="text-center">Others</td>
                                       </tr>
                                    </tbody>
                                    <!-- === Employee Details Tbody ===  -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Employee Details</th>
                                          <td colspan="8"></td>
                                       </tr>
                                       <tr>
                                          <th>Full-Time Employees</th>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">Yes</td>
                                       </tr>
                                       <tr>
                                          <th>Part-Time Employees</th>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                       </tr>
                                       <tr>
                                          <th>Contractual Employees</th>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">Yes</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                       </tr>
                                    </tbody>
                                    <!-- === Authorized Locations Tbody ===  -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Authorized Locations</th>
                                          <td colspan="8"></td>
                                       </tr>
                                       <tr>
                                          <th>Work in Office</th>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                       </tr>
                                       <tr>
                                          <th>Work from Home</th>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                          <td class="text-center">No</td>
                                       </tr>
                                    </tbody>
                                    <!-- === System Information Tbody ===  -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">System Information</th>
                                          <td colspan="8"></td>
                                       </tr>
                                       <tr>
                                          <th>ACD Name</th>
                                          <td class="text-center">CISCO</td>
                                          <td class="text-center">INCONTACT</td>
                                          <td class="text-center">AVAYA</td>
                                          <td class="text-center">Other</td>
                                          <td class="text-center">CISCO</td>
                                          <td class="text-center">INCONTACT</td>
                                          <td class="text-center">AVAYA</td>
                                          <td class="text-center">Other</td>
                                       </tr>
                                       <tr>
                                          <th>WFM Tool</th>
                                          <td class="text-center">NICE</td>
                                          <td class="text-center">VERINT</td>
                                          <td class="text-center">ASPECT</td>
                                          <td class="text-center">CALABRIO</td>
                                          <td class="text-center">Other</td>
                                          <td class="text-center">NICE</td>
                                          <td class="text-center">VERINT</td>
                                          <td class="text-center">ASPECT</td>
                                       </tr>
                                       <tr>
                                          <th>Back office Tool</th>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                          <td class="text-center"></td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                           <!-- === Process Information Blocks === -->
                           <div class="summary_contaienr">
                              <h2>Process Information</h2>
                              <div class="table-responsive">
                                 <table class="table table-bordered summary_table summary_procee_table">
                                    <!-- === Account Tbody ===  -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Account Name</th>
                                          <td class="text-center">Apple</td>
                                          <td class="text-center">Microsoft</td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">LOB</th>
                                          <td class="text-center">Chat LOB</td>
                                          <td class="text-center">Voice LOB</td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">Channels</th>
                                          <td class="text-center">Chat</td>
                                          <td class="text-center">Email</td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">Country</th>
                                          <td class="text-center">India</td>
                                          <td class="text-center">India</td>
                                       </tr>
                                    </tbody>
                                    <!-- ======= Forecasting  ======= -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Forecasting</th>
                                          <td colspan="2" ></td>
                                       </tr>
                                       <tr>
                                          <td>Which Forecasting tool / software package is being utilised?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Which Forecasting model is being used?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>What are the key input parameters to the model?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>How frequently is the model revisited for goodness of fit?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>How do you measure the accuracy of your Forecasting model?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                    </tbody>
                                    <!-- ========= Staffing / Resource Planning  ======= -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Staffing / Resource Planning</th>
                                          <td colspan="2" ></td>
                                       </tr>
                                       <!-- Forecast Locks -->
                                       <tr>
                                          <th class="bg_light_th">Forecast Locks</th>
                                          <td colspan="2" ></td>
                                       </tr>
                                       <tr>
                                          <td>Who provides the Forecast / Lock which forms the base of Staff Planning?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>What is your staff locking model?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you generate Internal Forecast?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Which Forecast is used for Staff Planning?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <!-- AHT -->
                                       <tr>
                                          <th class="bg_light_th">AHT</th>
                                          <td colspan="2" ></td>
                                       </tr>
                                       <tr>
                                          <td>What AHT is used for Staff Planning?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>How do you calculate New Hire impact on the AHT?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <!-- FTE -->
                                       <tr>
                                          <th class="bg_light_th">FTE</th>
                                          <td colspan="2" ></td>
                                       </tr>
                                       <tr>
                                          <td>How do you generate FTE requirements?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <!-- In-Office Shrinkage -->
                                       <tr>
                                          <th class="bg_light_th">In-Office Shrinkage</th>
                                          <td colspan="2" ></td>
                                       </tr>
                                       <tr>
                                          <td>At what level are your In-Office Shrinkages planned?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you have set targets for each individual Aux/Activity code?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>In-Office shrinkage Forecasts are modeled on (please select the appropriate)</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <!-- Out-of-Office Shrinkage -->
                                       <tr>
                                          <th class="bg_light_th">Out-of-Office Shrinkage</th>
                                          <td colspan="2" ></td>
                                       </tr>
                                       <tr>
                                          <td>At what level are your Out-of-Office Shrinkages planned?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Vacation Forecasts are modeled on (please select the appropriate)</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Absenteeism Forecasts are modeled on (please select the appropriate)</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <!-- Schedule Inflex -->
                                       <tr>
                                          <th class="bg_light_th">Schedule Inflex</th>
                                          <td colspan="2" ></td>
                                       </tr>
                                       <tr>
                                          <td>Is Schedule Inflex considered in Staff planning?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>How is the Schedule Inflex estimated / calculated?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <!-- Attrition -->
                                       <tr>
                                          <th class="bg_light_th">Attrition</th>
                                          <td colspan="2" ></td>
                                       </tr>
                                       <tr>
                                          <td>How do you factor attrition in your staff plan?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you plan for Involuntary Attrition as a separate line item? (BQM, Promotions, Transfers etc.)</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <!-- Staff Planning Connects -->
                                       <tr>
                                          <th class="bg_light_th">Staff Planning Connects</th>
                                          <td colspan="2" ></td>
                                       </tr>
                                       <tr>
                                          <td>Do you have Inter-departmental Staff planning discussions?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>What is the frequency?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td colspan="3"><strong>Who decides the below:-</strong></td>
                                       </tr>
                                       <tr>
                                          <td>Staffing Plan (Validation & Signing off key assumptions such as AHT, Shrinkage etc.</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Adding Batches</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Removing Batches</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Cross Skilling</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Is there a client dependency for hiring batches?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you have a calibration calls with the Recruitment team</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>If Yes – Weekly or Monthly</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                    </tbody>
                                    <!-- ========= Scheduling  ======= -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Scheduling</th>
                                          <td colspan="2"></td>
                                       </tr>
                                       <tr>
                                          <td>Do you do Call Curve Analysis before deciding the Schedule Pattern?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>What is the frequency of the above?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>How do you create interval level Volume and AHT requirements?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>How do you manage the Headcount reconciliation process?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you run Manpower Dimensionioning exercise frequently to arrive at optimal HC mix (FT/PT/Split/Flexi?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>What is the frequency of the above?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you run & test different Schedule Patterns to identify best fit?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>What is the frequency of the above?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you plot all In-office shrinkages in your Schedules at Interval Level? 
                                             (Coaching, Team Meeting, Business Updates etc.)
                                          </td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you plot Out-of-Office shrinkage in your Schedules at Interval Level? (Vacation)</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you review IDP/Schedule deviation prior to schedule release?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you measure Schedule Efficiency?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>What is your target for Schedule Efficiency? (Please specify in %)</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>How do you measure the Schedule Efficiency?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>What is your internal target for Scheduling accuracy? (Requirment to Scheduled - Day/Intervals)</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>How do you measure the Schedule Accuracy?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Do you measure the impact of various Scheduling Constraints on the account in terms or FTE & Cost?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                    </tbody>
                                    <!-- ========= Intraday Management  ======= -->
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Intraday Management</th>
                                          <td colspan="2"></td>
                                       </tr>
                                       <tr>
                                          <td>Do you have a WFM Play book / Guide? E.g - Downtime Process, Calling Tree, Threshold & Skilling</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Does RTA have a daily read out call / RCA?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Does the RTA do real time skill management?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>Does RTA do Intra-day Reforecasting?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>How do you manage customers resources up or down Realtime?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                       <tr>
                                          <td>How do you manage and report, variance to plan Realtime?</td>
                                          <td></td>
                                          <td></td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                           <!-- === Process Information Blocks === -->
                           <div class="summary_contaienr">
                              <h2>File Information</h2>
                              <div class="table-responsive">
                                 <table class="table table-bordered summary_table summary_procee_table">
                                    <tbody>
                                       <tr>
                                          <th class="bg_dark_th">Account Name</th>
                                          <td class="text-center">Apple</td>
                                          <td class="text-center">Microsoft</td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">Forecasting</th>
                                          <td colspan="2"></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Process Document</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Model Sample File</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Accuracy Measurement / Result</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">Staffing / Resource Planning</th>
                                          <td colspan="2"></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Process Document</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Model Sample File</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Staffing Forecast Accuracy Result</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">Scheduling</th>
                                          <td colspan="2"></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Process Document</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Scheduling Model (only if done in Excel)</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Staffing Forecast Accuracy Result</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">IDP / Deviation File sample</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="bg_light_th">RTA / Intraday Management</th>
                                          <td colspan="2"></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Process Document</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Intraday Report Sample</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">Day-End Report Sample</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                       <tr>
                                          <th class="text-right">RCA/Post-Mortem Report Sample</th>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                          <td class="text-center"><i class="fad fa-file-check"></i></td>
                                       </tr>
                                    </tbody>
                                 </table>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
                  <div class="footerBtn-panel">
                     <button type="button" class="action-button previous previous_button">Back</button>
                     <button type="submit" class="action-button">Submit</button>
                  </div>
               </div>
            </fieldset>
         </form>
      </div>
   </div>
   <div class="overlayaccount"></div>
</div>
<!-- Clone Data Modal popup -->
<div class="modal fare bd-example-modal-lg" id="cloneDataModal" tabindex="-1" role="dialog" aria-hidden="true">
   <div class="modal-dialog modal-lg modal-dialog-scrollable" role="document">
      <div class="modal-content">
         <div class="modal-header">
            <h5 class="modal-title" id="example-Modal3">Clone Data</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
               aria-hidden="true">&times;</span></button>
         </div>
         <div class="modal-body setup-content">
            <div class="fielset_panel p-0" style="min-height:600px;">
               <form id="msform" action="" method="post" class="text-left">
                  <div class="row mb-4">
                     <div class="col col-md-12">
                        <h4>Account Name - <span style="font-weight:600;">Apple</span></h4>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col col-md-6 col-12">
                        <div class="form-group">
                           <label>From LOB</label>
                           <select class="selectpicker form-control" title="Please Select">
                              <option>LOB 1</option>
                              <option>LOB 2</option>
                              <option>LOB 3</option>
                              <option>LOB 4</option>
                           </select>
                        </div>
                     </div>
                     <div class="col col-md-6 col-12">
                        <div class="form-group">
                           <label>To LOB</label>
                           <select class="selectpicker form-control" title="Please Select">
                              <option>LOB 1</option>
                              <option>LOB 2</option>
                              <option>LOB 3</option>
                              <option>LOB 4</option>
                           </select>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col col-md-6 col-12">
                        <div class="form-group">
                           <label>From Channel</label>
                           <select class="selectpicker form-control" title="Please Select">
                              <option>Voice - IB</option>
                              <option>Voice - OB</option>
                              <option>Chat</option>
                              <option>Email</option>
                              <option>Back Office</option>
                              <option>Social Media</option>
                              <option>Other</option>
                           </select>
                        </div>
                     </div>
                     <div class="col col-md-6 col-12">
                        <div class="form-group">
                           <label>To Channel</label>
                           <select class="selectpicker form-control" title="Please Select">
                              <option>Voice - IB</option>
                              <option>Voice - OB</option>
                              <option>Chat</option>
                              <option>Email</option>
                              <option>Back Office</option>
                              <option>Social Media</option>
                              <option>Other</option>
                           </select>
                        </div>
                     </div>
                  </div>
                  <div class="row">
                     <div class="col col-12 text-right mt-4">
                        <!-- <button type="button" class="btnWithLogo btnActionPro mr-3" data-toggle="modal"
                           data-target="#BatchReadyModal" data-dismiss="modal">Process</button> -->
                        <button type="button" class="btnWithLogo addcopyData">Copy Data</button>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
   $(document).ready(function(e) {
   
       $('[data-toggle="tooltip"]').tooltip();
       $('[data-toggle="popover"]').popover();;
       $('.popover-dismiss').popover({
           trigger: 'focus'
       });
   
       $('.selectpicker').selectpicker('refresh');
       
   
   
       $('#accountClose').on('click', function() {
           $('#accountSidebar').removeClass('active');
           $('.overlayaccount').removeClass('active');
       });
   
       $('.letstartBtn').on('click', function() {
           $('#accountSidebar').addClass('active');
           $('.overlayaccount').addClass('active');
       });
   
       $(".billing_cap_input").hide();
       $("#billingCapDrop").on("change", function(){  
           if ($(this).val()=="occupancy")
           {
               $("#biilingCapSec").hide();
               $("#biilingCapPer").show();
           }
           else if ($(this).val()=="aht") {
               $("#biilingCapPer").hide();
               $("#biilingCapSec").show();
               
           } else {
               $(".billing_cap_input").hide();
           }
       });
   
       $('.fielset_height').css('height', $(window).height() - ($('.progressbar_ul').height() + 40) + 'px');
       $('.scrollbarbar').scrollbar();
   
   });
</script>
<!-- ==== Add Account Code === -->
<script>
   $(document).ready(function(){
       var i= 0,j=0,acc_count=0,lob_count=0;
       // ========== Append Account Code =========
       function account_code(i){
       var cancel_button = `<button type="button" class="remove_account" data-toggle="tooltip" data-placement="top" title="Remove Account">
                           <i class="fas fa-trash-alt"></i></button>`;
       var account = `<div class="table-responsive table-container" data-account="`+i+`">
                       <table class="table account_table">
                       <thead>
                       <tr>
                       <th scope="col">Account Name</th>
                       <th scope="col">LOB</th>
                       <th scope="col">Channels</th>
                       <th scope="col">Country</th>
                       <th scope="col">City Name</th>
                       <th scope="col">Site Name</th>
                       <th scope="col">FTEs</th>
                       </tr>
                       </thead>
                       <tbody>
                       <tr>
                       <td>
                       <div class="form-group">
                       <input type="text" class="form-control" placeholder="Account Name" name="account_name[]" id="account_name">
                       </div>
                       </td>
                       <td>
                       <div class="form-group">
                       <input type="text" class="form-control" placeholder="Enter LOB" name="lob[`+i+`][]" id="lob">
                       </div>
                       </td>
                       <td>
                       <div class="form-group">
                       <select class="selectpicker form-control" title="Select Channel" data-live-search="true" name="channel[`+i+`][0][]" id="channel">
                       <option>Voice - IB</option>
                       <option>Voice - OB</option>
                       <option>Chat</option>
                       <option>Email</option>
                       <option>Back Office</option>
                       <option>Social Media</option>
                       <option>Other</option>
                       </select>
                       </div>
                       </td>
                       <td>
                       <div class="form-group">
                       <select class="selectpicker form-control" title="Select Country" data-live-search="true" name="country[]" id="country">
                       <option>Afghanistan</option>
                       <option>Albania</option>
                       <option>Algeria</option>
                       <option>Andorra</option>
                       <option>Angola</option>
                       <option>Antigua and Barbuda</option>
                       <option>Argentina</option>
                       <option>Armenia</option>
                       <option>Australia</option>
                       <option>Austria</option>
                       <option>Azerbaijan</option>
                       <option>Bahamas</option>
                       <option>Bahrain</option>
                       <option>Bangladesh</option>
                       <option>Barbados</option>
                       <option>Belarus</option>
                       <option>Belgium</option>
                       <option>Belize</option>
                       <option>Benin</option>
                       <option>Bhutan</option>
                       <option>Bolivia</option>
                       </select>
                       </div>
                       </td>
                       <td>
                       <div class="form-group">
                       <select class="selectpicker form-control" title="Select City" data-live-search="true"  name="city[]" id="city">
                       <option>Clark 03</option>
                       <option>Bacolod City</option>
                       <option>Davao 02</option>
                       <option>Iloilo 04</option>
                       <option>Santa Rosa</option>
                       <option>Wallerfield</option>
                       <option>Noida</option>
                       <option>Mt Laurel</option>
                       <option>Naperville</option>
                       <option>Pueblo</option>
                       <option>Richfield</option>
                       <option>Davao</option>
                       <option>Iloilo 02</option>
                       <option>Clark 01</option>
                       <option>Montreal</option>
                       <option>Barataria</option>
                       <option>Fairview</option>
                       <option>North Charleston</option>
                       <option>Charlotte</option>
                       <option>Clark 05</option>
                       <option>Plymouth</option>
                       </select>
                       </div>
                       </td>
                       <td>
                       <div class="form-group">
                       <input type="text" class="form-control" placeholder="Enter Site Name" name="site_name[]" id="site_name">
                       </div>
                       </td>
                       <td>
                       <div class="form-group">
                       <input type="text" class="form-control" placeholder="Enter FTE" name="fte[]" id="fte">
                       </div>
                       </td>
                       </tr>
                       <tr class="tr_channel">
                       <td colspan="6"></td>
                       <td class="text-right"><button type="button" class="add_chaneels channel-${i}" data-row="${i}"><i class="fas fa-plus-circle"></i> Add Channel</button></td>
                       </tr>
                       </tbody>
                       </table>
                       <div class="tableAction">${cancel_button}
                       <div class="childAction">
                       <button type="button" class="addLobBtn"><i class="fas fa-plus-circle"></i> Add LOB</button>
                       </div>
                       </div>`;
       return account;
       }
   
       // ========== Append LOB Code =========
       function lob_code(i){
       var lob =   `<tr class="rowLob" data-lob="`+lob_count+`">
                   <td class="text-left">
                   <button type="button" class="formremove removeLob_row" data-toggle="tooltip" data-placement="top" title="Remove LOB">
                   <i class="fas fa-trash-alt"></i></button></td>
                   <td>
                   <div class="form-group">
                   <input type="text" class="form-control" placeholder="Enter LOB" name="lob[`+acc_count+`][]">
                   </div>
                   </td>
                   <td>
                   <div class="form-group">
                   <select class="selectpicker form-control" title="Select Channel" data-live-search="true" name="channel[`+acc_count+`][`+lob_count+`][]">
                   <option>Voice - IB</option>
                   <option>Voice - OB</option>
                   <option>Chat</option>
                   <option>Email</option>
                   <option>Back Office</option>
                   <option>Social Media</option>
                   <option>Other</option>
                   </select>
                   </div>
                   </td>
                   <td>
                   <div class="form-group">
                   <select class="selectpicker form-control" title="Select Country" data-live-search="true" name="country[]">
                   <option>Afghanistan</option>
                   <option>Albania</option>
                   <option>Algeria</option>
                   <option>Andorra</option>
                   <option>Angola</option>
                   <option>Antigua and Barbuda</option>
                   <option>Argentina</option>
                   <option>Armenia</option>
                   <option>Australia</option>
                   <option>Austria</option>
                   <option>Azerbaijan</option>
                   <option>Bahamas</option>
                   <option>Bahrain</option>
                   <option>Bangladesh</option>
                   <option>Barbados</option>
                   <option>Belarus</option>
                   <option>Belgium</option>
                   <option>Belize</option>
                   <option>Benin</option>
                   <option>Bhutan</option>
                   <option>Bolivia</option>
                   </select>
                   </div>
                   </td>
                   <td>
                   <div class="form-group">
                   <select class="selectpicker form-control" title="Select City" data-live-search="true" name="city[]">
                   <option>Clark 03</option>
                   <option>Bacolod City</option>
                   <option>Davao 02</option>
                   <option>Iloilo 04</option>
                   <option>Santa Rosa</option>
                   <option>Wallerfield</option>
                   <option>Noida</option>
                   <option>Mt Laurel</option>
                   <option>Naperville</option>
                   <option>Pueblo</option>
                   <option>Richfield</option>
                   <option>Davao</option>
                   <option>Iloilo 02</option>
                   <option>Clark 01</option>
                   <option>Montreal</option>
                   <option>Barataria</option>
                   <option>Fairview</option>
                   <option>North Charleston</option>
                   <option>Charlotte</option>
                   <option>Clark 05</option>
                   <option>Plymouth</option>
                   </select>
                   </div>
                   </td>
                   <td>
                   <div class="form-group">
                   <input type="text" class="form-control" placeholder="Enter Site Name"  name="site_name[]">
                   </div>
                   </td>
                   <td>
                   <div class="form-group">
                   <input type="text" class="form-control" placeholder="Enter FTE" name="fte[]">
                   </div>
                   </td>
                   </tr>
                   <tr class="tr_channel">
                   <td colspan="6"></td>
                   <td class="text-right"><button type="button" class="add_chaneels" data-lob="`+lob_count+`"><i class="fas fa-plus-circle"></i> Add Channel</button></td>
                   </tr>`;
       return lob;
       }
   
       // ========== Append LOB Code =========
       function channel_code(i,lobb){
       var channel =   `<tr>
                       <td colspan="2" class="text-left">
                       <button type="button" class="formremove remove_channels" data-toggle="tooltip" data-placement="top" title="Remove Channel">
                       <i class="fas fa-trash-alt"></i></button></td>
                       <td>
                       <div class="form-group">
                       <select class="selectpicker form-control" title="Select Channel" data-live-search="true" name=channel_name[0][]>
                       <option>Voice - IB</option>
                       <option>Voice - OB</option>
                       <option>Chat</option>
                       <option>Email</option>
                       <option>Back Office</option>
                       <option>Social Media</option>
                       <option>Other</option>
                       </select>
                       </div>
                       </td>
                       <td>
                       <div class="form-group">
                       <select class="selectpicker form-control" title="Select Country" data-live-search="true">
                       <option>Afghanistan</option>
                       <option>Albania</option>
                       <option>Algeria</option>
                       <option>Andorra</option>
                       <option>Angola</option>
                       <option>Antigua and Barbuda</option>
                       <option>Argentina</option>
                       <option>Armenia</option>
                       <option>Australia</option>
                       <option>Austria</option>
                       <option>Azerbaijan</option>
                       <option>Bahamas</option>
                       <option>Bahrain</option>
                       <option>Bangladesh</option>
                       <option>Barbados</option>
                       <option>Belarus</option>
                       <option>Belgium</option>
                       <option>Belize</option>
                       <option>Benin</option>
                       <option>Bhutan</option>
                       <option>Bolivia</option>
                       </select>
                       </div>
                       </td>
                       <td>
                       <div class="form-group">
                       <select class="selectpicker form-control" title="Select City" data-live-search="true">
                       <option>Clark 03</option>
                       <option>Bacolod City</option>
                       <option>Davao 02</option>
                       <option>Iloilo 04</option>
                       <option>Santa Rosa</option>
                       <option>Wallerfield</option>
                       <option>Noida</option>
                       <option>Mt Laurel</option>
                       <option>Naperville</option>
                       <option>Pueblo</option>
                       <option>Richfield</option>
                       <option>Davao</option>
                       <option>Iloilo 02</option>
                       <option>Clark 01</option>
                       <option>Montreal</option>
                       <option>Barataria</option>
                       <option>Fairview</option>
                       <option>North Charleston</option>
                       <option>Charlotte</option>
                       <option>Clark 05</option>
                       <option>Plymouth</option>
                       </select>
                       </div>
                       </td>
                       <td>
                       <div class="form-group">
                       <input type="text" class="form-control" placeholder="Enter Site Name">
                       </div>
                       </td>
                       <td>
                       <div class="form-group">
                       <input type="text" class="form-control" placeholder="Enter FTE">
                       </div>
                       </td>
                       </tr>`;
           return channel;
           }
   
       for(; i<=0; i++)
       {
           $('.account_more').append(account_code(i));
           j++;
       }
   
      // ========== Append Account Add and Delete on Click Code =========
       $('#addmore_acount').click(function(){
           $('.account_more').append(account_code(i));
           $('.selectpicker').selectpicker('refresh');
           //$('.datepicker').datetimepicker('refresh');
           i++;j++;
       });
       $(document).on('click','.remove_account',function(){
           $(this).parent().parent().remove();
       });
   
   
       // ========== Append LOB Add and Delete on Click Code =========
       $(document).on('click','.addLobBtn',function(){
           acc_count=$(this).parent().parent().parent().attr('data-account');
           lob_count=$(this).parent().parent().parent().find('.rowLob').length
           lob_count=lob_count+1;
           $(this).parent().parent().parent().find('table tbody').append(lob_code(0));
           $('.selectpicker').selectpicker('refresh');
           //i++;j++;
       });
       $(document).on('click','.removeLob_row',function(){
           $(this).parent().parent().nextUntil("tr.rowLob").remove();
           $(this).parent().parent().remove();
       });
   
   
       // ========== Append Channel Add and Delete on Click Code =========
       $(document).on('click','.add_chaneels',function(){
           $(this).closest('tr').before(channel_code(0),$(this).attr('data-lob'));
           $('.selectpicker').selectpicker('refresh');
       });
       $(document).on('click','.remove_channels',function(){
           $(this).parent().parent().remove();
       });
   
   });
</script>
<!-- ==== Multi Step Form Code === -->
<script>
   ;
   (function($) {
       "use strict";
   
       //* Form js
       function verificationForm() {
           //jQuery time
           var current_fs, next_fs, previous_fs,form_name; //fieldsets
           var left, opacity, scale; //fieldset properties which we will animate
           var animating; //flag to prevent quick multi-click glitches
   
           $(".next").click(function() {
               if (animating) return false;
               animating = true;
   
               current_fs = $(this).parent().parent().parent().parent();
               next_fs = $(this).parent().parent().parent().parent().next();
   
               //activate next step on progressbar using the index of next_fs
               $("#progressbarAct li").eq($("fieldset").index(next_fs)).addClass("active");
               form_name=$(current_fs).attr('data-name');
               if($(current_fs).attr('data-route')){
                  $.ajaxSetup({
                      headers: {
                          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                      }
                  });
                   $.ajax({
                       type: "POST",
                       url: $(current_fs).attr('data-route'),
                       data: $(current_fs).serialize(), // serializes the form's elements.
                       success: function(data)
                       {
                           if(data.success){
                              if(data.data.client_id){
                                 $('.client_id').val(data.data.client_id);
                              }
                           }
                       }
                  });
               }
              

               //console.log($('#accountForms').serialize());
               //show the next fieldset
               next_fs.show();
               //hide the current fieldset with style
               current_fs.animate({
                   opacity: 0
               }, {
                   step: function(now, mx) {
                       //as the opacity of current_fs reduces to 0 - stored in "now"
                       //1. scale current_fs down to 80%
                       scale = 1 - (1 - now) * 0.2;
                       //2. bring next_fs from the right(50%)
                       left = (now * 50) + "%";
                       //3. increase opacity of next_fs to 1 as it moves in
                       opacity = 1 - now;
                       current_fs.css({
                           'transform': 'scale(' + scale + ')',
                           'position': 'absolute'
                       });
                       next_fs.css({
                           'left': left,
                           'opacity': opacity
                       });
                   },
                   duration: 800,
                   complete: function() {
                       current_fs.hide();
                       animating = false;
                   },
                   //this comes from the custom easing plugin
                   //easing: 'easeInOutBack'
               });
           });
   
           $(".previous").click(function() {
               if (animating) return false;
               animating = true;
   
               current_fs = $(this).parent().parent().parent().parent();
               previous_fs = $(this).parent().parent().parent().parent().prev();
   
               //de-activate current step on progressbar
               $("#progressbarAct li").eq($("fieldset").index(current_fs)).removeClass("active");
   
               //show the previous fieldset
               previous_fs.show();
               //hide the current fieldset with style
               current_fs.animate({
                   opacity: 0
               }, {
                   step: function(now, mx) {
                       //as the opacity of current_fs reduces to 0 - stored in "now"
                       //1. scale previous_fs from 80% to 100%
                       scale = 0.8 + (1 - now) * 0.2;
                       //2. take current_fs to the right(50%) - from 0%
                       left = ((1 - now) * 50) + "%";
                       //3. increase opacity of previous_fs to 1 as it moves in
                       opacity = 1 - now;
                       current_fs.css({
                           'left': left
                       });
                       previous_fs.css({
                           'transform': 'scale(' + scale + ')',
                           'opacity': opacity
                       });
                   },
                   duration: 800,
                   complete: function() {
                       current_fs.hide();
                       animating = false;
                   },
                   //this comes from the custom easing plugin
                   //easing: 'easeInOutBack'
               });
           });
   
           $(".submit").click(function() {
               return false;
           })
       };
   
       /*Function Calls*/
       verificationForm();
   })(jQuery);
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\wfm\resources\views/index.blade.php ENDPATH**/ ?>